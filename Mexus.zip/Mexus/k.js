const express = require('express');
const axios = require('axios');
const app = express();

// Configuração da porta
const PORT = 3000;

// Rota para obter informações pelo ID
app.get('/getlike/:id&key=:key', async (req, res) => {
  const id = req.params.id;
  const apiKey = req.params.key;
  const url = `https://drxzsecurityapi.info/sendlike.php/api/like/${id}?key=${apiKey}`;

  try {
    const response = await axios.get(url);
    res.json(response.data); // Retorna a resposta da API
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao obter os dados da API.' });
  }
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});