const express = require("express");
const fs = require("fs-extra");
const session = require('express-session');
const bodyParser = require("body-parser");
const MongoStore = require('connect-mongo');
const path = require('path');
const app = express();
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const PORT = 2134;
const multer = require('multer');
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const bcrypt = require('bcryptjs');
const saltRounds = 10;
const domain = `http://localhost:3000 na porta ${PORT}`
const users = JSON.parse(fs.readFileSync('./users.json', 'utf-8'));
const chats = JSON.parse(fs.readFileSync('./chats.json', 'utf-8'));
const ids = JSON.parse(fs.readFileSync('./idbs.json', 'utf-8'));
const idc = JSON.parse(fs.readFileSync('./idbc.json', 'utf-8'));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './uploads');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

app.use(session({
  secret: 'segredo', // Substitua por algo seguro
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: 'mongodb+srv://roohmodder:5AlYCu8EEm94kyaW@roohmexus.imdwv.mongodb.net/?retryWrites=true&w=majority&appName=RoohMexus',
    ttl: 60 * 60 * 24 * 7 // Sessão válida por 7 dias
  }),
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7, // Cookie válido por 7 dias
    secure: false, // Coloque `true` se estiver usando HTTPS
    httpOnly: true
  }
}));

app.use(bodyParser.json({ limit: '50mb' }));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const USERS_FILE = "./users.json";
const CHATS_FILE = "./chats.json";

// Inicializa o arquivo de conversas, se não existir
if (!fs.existsSync(CHATS_FILE)) {
  fs.writeFileSync(CHATS_FILE, JSON.stringify([]));
}

const loadUsers = () => {
  if (fs.existsSync(USERS_FILE)) {
    const data = fs.readFileSync(USERS_FILE);
    return JSON.parse(data);
  }
  return [];
};

const loadAdms = () => {
  if (fs.existsSync('./admin.json')) {
    const data = fs.readFileSync('./admin.json');
    return JSON.parse(data);
  }
  return [];
};

const loadIds = () => {
  if (fs.existsSync('./idbs.json')) {
    const data = fs.readFileSync('./idbs.json');
    return JSON.parse(data);
  }
  return [];
};

const loadIdc = () => {
  if (fs.existsSync('./idbc.json')) {
    const data = fs.readFileSync('./idbc.json');
    return JSON.parse(data);
  }
  return [];
};

const loadSttgs = () => {
  if (fs.existsSync('./sttgs.json')) {
    const data = fs.readFileSync('./sttgs.json');
    return JSON.parse(data);
  }
  return [];
};


const backupFile = (filepath) => {
  const backupPath = filepath + ".backup";
  try {
    if (fs.existsSync(filepath)) {
      fs.copyFileSync(filepath, backupPath);
      console.log(`Backup criado com sucesso: ${backupPath}`);
    }
  } catch (err) {
    console.error("Erro ao criar backup:", err);
  }
};

const validateUsers = (users) => {
  if (!Array.isArray(users)) return false;
  return users.every(user => user.id && typeof user.username === "string");
};

const saveUser = (users) => {
  if (!validateUsers(users)) {
    console.error("Dados inválidos detectados! Salvamento abortado.");
    return;
  }
  backupFile(`./backups/users(${Date.now()}).json`); // Cria o backup
  console.log("Salvando usuários no arquivo JSON...");
  writeToFileSafely(USERS_FILE, users, (err) => {
    if (err) {
      console.error("Erro ao salvar usuários:", err);
    } else {
      console.log("Usuários salvos com sucesso!");
    }
  });
};

function saveChats(chats) {
  fs.writeFileSync(CHATS_FILE, JSON.stringify(chats, null, 2));
}

const loadChats = () => {
  if (fs.existsSync(CHATS_FILE)) {
    const data = fs.readFileSync(CHATS_FILE);
    return JSON.parse(data);
  }
  return [];
};

function isAuthenticated(req, res, next) {
  const users = loadUsers();
  const user = users.find(u => u.id === req.session.userId);
  const mnt = loadSttgs();

  if (!user) {
    req.session.destroy();
    return res.redirect('/login');
  }

  if (user.id !== 1736352281318 && mnt.maintenance) {
    req.session.destroy();
    return res.status(403).send("⚒️ Plataforma em Manutenção.");
  }

  if (user.suspended) {
    req.session.destroy();
    return res.status(403).send(`⚠️ Sua conta está suspensa.`);
  }

  // Codifica a mensagem de sucesso com emoji
  const successMessage = Buffer.from(`✅ Login autorizado, ${user.name}!${mnt.notice? "\n⚠️ Notícia: "+mnt.notice:""}`).toString('base64');
  res.setHeader('X-Success-Message', successMessage);

  next(); // Prossegue para o próximo middleware ou rota
}

function isAuthenticated2(req, res, next) {
  const adms = loadAdms();
  const adm = adms.find(u => u.id === req.session.userId);

  if (!adm) {
    req.session.destroy();
    return res.redirect('/admin/login');
  }

  // Codifica a mensagem de sucesso com emoji
  const successMessage = Buffer.from(`✅ Login autorizado, ${adm.name}!`).toString('base64');
  res.setHeader('X-Success-Message', successMessage);

  next(); // Prossegue para o próximo middleware ou rota
}

function getUserById(userId) {
const users = loadUsers();
  return users.find(user => user.id === userId);
}

let isWriting = false;

function writeToFileSafely(filepath, data, callback) {
  const interval = setInterval(() => {
    if (!isWriting) {
      isWriting = true;
      fs.writeFile(filepath, JSON.stringify(data, null, 2), 'utf8', (err) => {
        isWriting = false;
        clearInterval(interval);
        if (callback) callback(err);
      });
    }
  }, 50);
}

function getVerificationBadge(verifications) {
    if (verifications.azul) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="blue" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (verifications.verde) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="green" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (verifications.vermelho) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="red" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (verifications.amarelo) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="yellow" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (verifications.roxo) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="purple" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (verifications.colorido) {
        return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="url(#grad1)" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path><defs><linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" style="stop-color:red;stop-opacity:1" /><stop offset="20%" style="stop-color:orange;stop-opacity:1" /><stop offset="40%" style="stop-color:yellow;stop-opacity:1" /><stop offset="60%" style="stop-color:green;stop-opacity:1" /><stop offset="80%" style="stop-color:blue;stop-opacity:1" /><stop offset="100%" style="stop-color:purple;stop-opacity:1" /></linearGradient></defs></svg>';
    }
    return ''; // Caso não haja verificação
}

app.get('/profile-user/:username', isAuthenticated, (req, res) => {
    const users = loadUsers();
    const userId = req.session.userId;
    const user2 = users.find(u => u.id == userId);
    const ids = loadIds();
    fs.readFile(path.join(__dirname, 'users.json'), 'utf8', (err, data) => {
        if (err) {
            res.status(500).send("Erro ao ler arquivo de usuários");
            return;
        }

        const loggedUser = user2.id;  // Agora usamos o ID do usuário logado
        const username = req.params.username;  // O usuário que estamos visualizando

        const loggedUserObj = users.find(u => u.id === loggedUser);  // Encontramos o usuário logado pelo ID
        const profileUserObj = users.find(u => u.username === username);  // Encontramos o perfil pelo username

        if (!profileUserObj) {
            return res.status(404).send('Usuário não encontrado!');
        }

        // Verificar se o usuário logado está seguindo o usuário visitado usando o ID
        const isFollowing = loggedUserObj.following.includes(profileUserObj.id);

       const formatLegend = (legend) => {
    if (!legend) return '';
    return legend
        .replace(/@([a-zA-Z0-9_.]+)/g, (match, username) => {
            const mentionedUser = users.find(u => u.username === username);
            if (mentionedUser) {
                return `<a href="/profile-user/${mentionedUser.username}" style="color: #639af2; text-decoration: none;">${match}</a>`;
            }
            return match;
        })
        .replace(/\n/g, '<br>'); // Substitui quebra de linha por <br>
};

let verificationBadge = getVerificationBadge(profileUserObj.verifications);

        res.send(`
            <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
                    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
                    <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Perfil - ${profileUserObj.name}</title>
                  <style>
                        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            font-family: Arial, sans-serif;
            color: #fff;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            border-bottom: 1px solid #333;
        }
        .header span {
            font-size: 18px;
        }
        .header .profile-name {
            display: flex;
            align-items: center;
        }
        .header .profile-name svg {
            margin-left: 5px;
            cursor: pointer;
        }   
        .profile {
            padding: 20px 15px;
            display: flex;
            align-items: center;
        }
        .profile-pic {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            border: 2px solid #fff;
            margin: 7px;
        }
        .profile-info {
            margin-left: 15px;
            flex-grow: 1;
        }
        .profile-info h1 {
            font-size: 16px;
            margin: -20px 0 0;
        }
        .profile-info p {
            margin: 2px 0;
            font-size: 14px;
            color: #aaa;
        }
        .profile-info p2 {
            margin: 2px 0;
            font-size: 14px;
            color: #639af2;
        }
        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 0px;
            gap: 20px;
            margin: 0px;
            padding: 7px;
        }
        .stats div {
            text-align: center;
        }
        .stats div strong {
            display: block;
            font-size: 16px;
        }
        .buttons {
            display: flex;
            justify-content: space-around;
            border-bottom: 1px solid #333;
            margin-top: -8px;
            padding: 15px;
        }
        .buttons button {
            background: none;
            border: 1px solid #555;
            border-radius: 5px;
            padding: 3px 45px;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
        }
        .buttons button:hover {
            background-color: #333;
        }
        .highlights {
            display: flex;
            justify-content: space-evenly;
            margin: 20px 0;
        }
        .highlights img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 2px solid #333;
        }
 .posts {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    margin-top: 10px;
    padding: 0;
    gap: 3px;
}

.posts a {
    display: block; /* Faz o <a> se comportar como bloco */
    width: calc((100% - 10px) / 3); /* Garante o alinhamento com as imagens */
    aspect-ratio: 1 / 1; /* Mantém a proporção quadrada */
}

.posts img {
    width: 100%; /* Faz a imagem ocupar todo o espaço do <a> */
    height: 100%; /* Garante que a imagem preencha o espaço */
    object-fit: cover; /* Ajusta o conteúdo dentro do espaço */
    border-radius: 0px;
}
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0);
            backdrop-filter: blur(10px);
            justify-content: center;
            align-items: center;
            z-index: 999; /* Garante que a pop-up fique sobre outros elementos */
        }
        .popup-content {
            background-color: #1c1c1c;
            width: 80%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            padding: 20px;
            position: relative;
            margin: 0 auto; /* Garantindo que fique centralizado */
        }
        .popup-content h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .popup-content h2 {
            font-size: 20px;
            margin-bottom: -25px;
        }
        .popup-content .profile-img {
           width: 100px;
           height: 100px;
           border-radius: 50%;
           margin-bottom: -10px;
           margin-top: -30px;
        }

        .popup-content .verified {
            color: #4aa1ec;
            font-size: 18px;
        }

        .popup-content .details {
            border-top: 1px solid #333;
            padding-top: 20px;
            margin-top: 20px;
        }

        .popup-content .detail {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .popup-content .icon {
            font-size: 24px;
            color: white;
            margin-right: 15px;
        }

        .close-popup {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #fff;
            font-size: 24px;
            cursor: pointer;
        }
                    .footer-menu {
                position: fixed;
                bottom: 0;
                left: 0;
                width: 100%;
                background-color: #121212;
                border-top: 1px solid #333;
                display: flex;
                justify-content: space-around;
                align-items: center;
                padding: 10px 0;
                z-index: 1000;
            }
            .footer-menu img {
                width: 28px;
                height: 28px;
            }
                    </style>
                </head>
                <body>
                
                    <div class="footer-menu">
        <a href="/" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/home.png" alt="Home Icon">
            </a>
            
            <a href="/search" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/search--v1.png" alt="Search Icon">
          </a>
              <a href="/post" >
  <img src="https://img.icons8.com/ios-filled/50/ffffff/plus-math.png" alt="Add Icon">
</a>
            
            
           <a href="/profile" >
             <img src="${user2.photo}" alt="Profile Icon" style="border-radius: 50%;">
             </a>
        </div>
                
                    <div class="header">
                        <div class="profile-name" onclick="showPopup(event)">
                            <span>${profileUserObj.username}</span>
                            ${verificationBadge}
                        </div>
                        <a href="" >
                        <span><i class="fas fa-ellipsis-v"></i></span>
                    </div>
                    </a>

                    <div class="profile">
                        <img src="${profileUserObj.photo}" alt="Perfil" class="profile-pic">
                    
                        <div class="stats">
                            <div>
                                <strong>${profileUserObj.posts.length}</strong>
                                <span>Posts</span>
                            </div>
                            <div>

<strong>
${ids.ids.includes(profileUserObj.id) ? 
    (profileUserObj.followersB >= 1_000_000 ? (profileUserObj.followersB / 1_000_000).toFixed(1) + 'M' :
      profileUserObj.followersB >= 1_000 ? (profileUserObj.followersB / 1_000).toFixed(1) + 'K' :
      profileUserObj.followersB) 
    : 
    `<span id="followers-count">` + 
    (profileUserObj.followers.length >= 1_000_000 ? (profileUserObj.followers.length / 1_000_000).toFixed(1) + 'M' :
      profileUserObj.followers.length >= 1_000 ? (profileUserObj.followers.length / 1_000).toFixed(1) + 'K' :
      profileUserObj.followers.length) + 
    `</span>`}
</strong>

                                <span>Seguidores</span>
                            </div>
                            <div>
                                <strong>${profileUserObj.following.length}</strong>
                                <span>Seguindo</span>
                            </div>
                        </div>
                    </div>
                    <div class="profile-info">
                        <h1>${profileUserObj.name}</h1>
                        <p2>${profileUserObj.category? profileUserObj.category:''}</p>
                                <p>${formatLegend(profileUserObj.legend || '')}</p>
                    </div>
                    <div class="buttons">
        <button class="follow-btn" data-username="${profileUserObj.username}">
            ${isFollowing ? 'Seguindo' : 'Seguir'}
        </button>
                        <a href="/chat/${profileUserObj.id}" >
                        <button>Mensagem</button>
                        </a>
                    </div>

                    <div class="posts">
    ${profileUserObj.posts
        .sort((a, b) => {
            // Extrair a data e hora do formato "Dia 05/01/2025 às 22:22"
            const getDateTime = post => {
                const regex = /dia (\d{2})\/(\d{2})\/(\d{4}) às (\d{2}):(\d{2})/;
                const [, day, month, year, hour, minute] = post.DateTime.match(regex);
                return new Date(`${year}-${month}-${day}T${hour}:${minute}:00`);
            };
            
            return getDateTime(b) - getDateTime(a);
        })
        .map(post => {
            // Verifica a extensão do arquivo para identificar se é um vídeo
            const fileExtension = post.Post.split('.').pop().toLowerCase();
            
            // Se for um vídeo
            if (['mp4', 'webm', 'ogg'].includes(fileExtension)) {
                return `
                <a href="/posti/${post.postId}" style="position: relative; display: block;">
                    <!-- Imagem de thumbnail do vídeo com botão de play -->
      <img src="/uploads/play.png" alt="k">
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(0%, 0%); background: rgba(0, 0, 0, 0); padding: 15px; border-radius: 50%; color: white; font-size: 24px; display: flex; justify-content: center; align-items: center;">
                       
                    </div>
                </a>
                `;
            } else {
                // Se for uma imagem
                return `
                <a href="/posti/${post.postId}">
                    <img src="${post.Post}" alt="Post Image" style="width: 100%; height: 100%; object-fit: cover;">
                </a>
                `;
            }
        }).join('')}
</div>
                    <!-- Popup -->
                    <div class="popup-overlay" id="popupOverlay" onclick="closePopup(event)">
                        <div class="popup-content">
                            <h1>Sobre esta conta</h1>
                            <div class="profile" style="display: flex; flex-direction: column; align-items: center;">
                                <img src="${profileUserObj.photo}" alt="Perfil" class="profile-img">
                                <h2>${profileUserObj.username}
                                    ${verificationBadge}
                                </h2>
                            </div>
                            <div class="details">
                                <div class="detail">
                                    <i class="fas fa-calendar-alt icon"></i>
                                    <p><strong>Data de entrada</strong><br>Janeiro de 2025</p>
                                </div>
                                <div class="detail">
                                    <i class="fas fa-map-marker-alt icon"></i>
                                    <p><strong>Conta situada em</strong><br>${profileUserObj.country}</p>
                                </div>
   <div class="detail">
    ${verificationBadge ? `
        <div class="detail" style="display: flex; align-items: center; gap: 2px;">
            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" 
                width="2em" height="2em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" 
                data-icon="ic:baseline-verified">
                <path fill="white" stroke="" stroke-width="1" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path>
            </svg>
            <p><strong>Verificado</strong><br></p>
        </div>
    ` : ''}
</div>

                    <script>

document.querySelector('.follow-btn').addEventListener('click', () => {
                const button = document.querySelector('.follow-btn');
                const followedUsername = button.getAttribute('data-username');

                fetch('/follow', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username: followedUsername }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Atualizar o texto do botão
                        button.textContent = data.isFollowing ? 'Seguindo' : 'Seguir';

                        // Atualizar a contagem de seguidores
                        document.getElementById('followers-count').textContent = data.followersCount;
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                });
            });

                        function showPopup(event) {
                            event.stopPropagation();
                            document.getElementById("popupOverlay").style.display = "flex";
                        }

                        function closePopup(event) {
                            if (event.target === document.getElementById("popupOverlay")) {
                                document.getElementById("popupOverlay").style.display = "none";
                            }
                        }
                    </script>
        `);
    });
});

app.post('/follow', (req, res) => {
    const userId = req.session.userId;
    const users = loadUsers();
    const loggedUser = users.find(u => u.id === userId);
    const { username: followedUsername } = req.body;

    if (!loggedUser) {
        return res.status(404).json({ success: false, message: "Usuário não encontrado" });
    }

    const profileUser = users.find(u => u.username === followedUsername);

    if (!profileUser) {
        return res.status(404).json({ success: false, message: "Usuário não encontrado!" });
    }

    // Agora estamos adicionando ou removendo pelo ID
    if (loggedUser.following.includes(profileUser.id)) {
        loggedUser.following = loggedUser.following.filter(userId => userId !== profileUser.id);
        profileUser.followers = profileUser.followers.filter(followerId => followerId !== loggedUser.id);
    } else {
        loggedUser.following.push(profileUser.id);
        profileUser.followers.push(loggedUser.id);
    }

    writeToFileSafely("users.json", users, (err) => {
        if (err) {
            console.error("Erro ao salvar o arquivo:", err);
            return res.status(500).json({ success: false, message: "Erro ao salvar o arquivo" });
        }

        res.json({
            success: true,
            isFollowing: loggedUser.following.includes(profileUser.id),
            followersCount: profileUser.followers.length,
        });
    });
});


// Rota para solicitação de redefinição de senha
app.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(400).send('Usuário não encontrado.');
  }

  // Gera um token de redefinição de senha
  const token = crypto.randomBytes(32).toString('hex');
  user.resetToken = token;
  user.resetTokenExpiry = Date.now() + 3600000; // Token válido por 1 hora
  saveUser(users);

  // Envia o e-mail com o link de redefinição de senha
  const transporter = nodemailer.createTransport({
    host: "smtp.zoho.com",
    port: 465,
    secure: true,
    auth: {
      user: "russin07hz@rooh.top",
      pass: "97206515Russin!",
    }
  });

  const mailOptions = {
    from: 'russin07hz@rooh.top',
    to: user.email,
    subject: 'Redefinição de Senha',
    text: `Você solicitou a redefinição de senha. Clique no link abaixo para criar uma nova senha:\n\n${domain}/reset-password/${token}`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return res.status(500).send('Erro ao enviar e-mail.');
    }
    res.send('E-mail de redefinição de senha enviado.');
  });
});

// Rota para redefinição de senha
app.post('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  const { newPassword } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.resetToken === token && u.resetTokenExpiry > Date.now());

  if (!user) {
    return res.status(400).send('Token inválido ou expirado.');
  }

  // Verifica se a nova senha tem pelo menos 8 dígitos
  if (newPassword.length < 8) {
    return res.status(400).send('A senha deve ter no mínimo 8 dígitos.');
  }

  // Gera o hash da nova senha
  const hashedPassword = await bcrypt.hash(newPassword, 10);
  user.password = hashedPassword;
  user.resetToken = undefined;
  user.resetTokenExpiry = undefined;
  saveUser(users);

  res.send('Senha redefinida com sucesso!');
});

// Rota para servir o HTML da solicitação de redefinição de senha
app.get('/resetpass', (req, res) => {
  res.sendFile(path.join(__dirname, 'resetpass.html'));
});

// Rota para servir o HTML da redefinição de senha com token
app.get('/reset-password/:token', (req, res) => {
  const { token } = req.params;
  res.sendFile(path.join(__dirname, 'resetpasss.html'));
});

app.get("/chat/:recipientId", isAuthenticated, (req, res) => {
  const users = loadUsers();
  const recipientId = Number(req.params.recipientId);
  const recipient = users.find((user) => user.id === recipientId);
  const user = recipient;

  if (!recipient) {
    return res.status(404).send("Usuário não encontrado.");
  }

  // Marca as mensagens como lidas
  const chats = loadChats();
  const chat = chats.find(chat => chat.participants.includes(user.id) && chat.participants.includes(req.session.userId));
  if (chat) {
    chat.messages.forEach(message => {
      if (message.senderId !== req.session.userId) {
        message.isUnread = false;
      }
    });
    saveChats(chats); // Salva os chats atualizados (crie essa função conforme necessário)
  }

let verificationBadge = getVerificationBadge(user.verifications);

  res.send(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Conversa no Mexus</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
      <style>
      body {
          background-color: #000;
          color: #fff;
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          display: flex;
          flex-direction: column;
          height: 93vh;
          max-width: 600px;
          margin: auto;
        }
        .header {
          display: flex;
          align-items: center;
          padding: 10px;
          border-bottom: 1px solid #333;
        }
        .header img {
          border-radius: 50%;
          width: 40px;
          height: 40px;
          margin-right: 10px;
        }
       .header .back-icon {
            font-size: 24px;
            color: #fff;
            margin-right: 10px;
            cursor: pointer;
            }
            .header .verified {
            color: #1DA1F2;
            margin-left: 5px;
            font-size: 16px;
        }
        .header .icons {
            margin-left: auto;
            display: flex;
            align-items: center;
        }
        .header .icons i {
            font-size: 24px;
            margin-left: 15px;
            color: #fff;
        }
        .header .name {
          font-size: 18px;
          font-weight: bold;
          display: flex;
          align-items: center;
        }
        .header .name svg {
          margin-left: 5px;
        }
        .chat {
          flex: 1;
          padding: 10px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
        }
        .chat .message {
          display: flex;
          align-items: flex-start;
          margin-bottom: 10px;
        }
        .chat .message img {
          border-radius: 50%;
          width: 30px;
          height: 30px;
          margin-right: 10px;
        }
        .chat .message .text {
          background-color: #1DA1F2;
          padding: 10px;
          border-radius: 20px;
          max-width: 70%;
          word-wrap: break-word;
        }
        .chat .message .text.user {
          background-color: #333;
          margin-left: auto;
        }
        .chat .message .text .time {
          color: #888;
          font-size: 12px;
          margin-top: 5px;
          text-align: right;
        }
        .input-area {
          display: flex;
          align-items: center;
          padding: 5px;
          border-top: 1px solid #333;
        }
        .input-area input {
          flex: 1;
          padding: 8px;
          border: none;
          border-radius: 20px;
          margin-right: 10px;
          background-color: #333;
          color: #fff;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <a href="/chats" >
          <i class="fas fa-arrow-left back-icon"></i>
        </a>
        <a href="/profile-user/${recipient.username}" >
          <img src="${recipient.photo}" alt="Profile Picture">
        </a>
        <div>
          <div class="name">${recipient.name} ${verificationBadge}</div>
          <div class="username">${recipient.username}</div>
        </div>
        <div class="icons">
          <i class="fas fa-phone"></i>
          <i class="fas fa-video"></i>
        </div>
      </div>
      <div class="chat" id="chat"></div>
      <div class="input-area">
        <input type="text" placeholder="Escreva uma mensagem..." id="messageInput">
        <i class="fab fa-telegram-plane" onclick="sendMessage()"></i>
      </div>
      <script src="/socket.io/socket.io.js"></script>
      <script>
        const socket = io();
        const chat = document.getElementById("chat");
        const messageInput = document.getElementById("messageInput");

        // IDs
        const recipientId = ${recipientId};
        const senderId = ${req.session.userId};

        fetch(\`/chat-history/\${recipientId}\`)
          .then(response => response.json())
          .then(messages => {
            messages.forEach(message => addMessage(message));
          });

        const addMessage = (message) => {
          const isUserMessage = message.senderId === senderId;
          const div = document.createElement("div");
          div.className = "message";
          div.innerHTML = isUserMessage
            ? \`<div class="text user">\${message.content}<div class="time">\${new Date(message.timestamp).toLocaleTimeString()}</div></div>\`
            : \`<img src="${recipient.photo}" alt="Profile Picture"><div class="text">\${message.content}<div class="time">\${new Date(message.timestamp).toLocaleTimeString()}</div></div>\`;
          chat.appendChild(div);
          chat.scrollTop = chat.scrollHeight;
        };

        const sendMessage = () => {
          const content = messageInput.value.trim();
          if (content) {
            const message = { senderId, recipientId, content, timestamp: new Date().toISOString(), isUnread: true };
            socket.emit("sendMessage", message);
            addMessage(message);
            messageInput.value = "";
          }
        };

        socket.on("newMessage", (message) => {
          if (message.recipientId === senderId || message.senderId === recipientId) {
            addMessage(message);
          }
        });
      </script>
    </body>
    </html>
  `);
});

app.get("/chat-history/:recipientId", isAuthenticated, (req, res) => {
  const senderId = req.session.userId; // Certifique-se de que o senderId está sendo passado corretamente
  const recipientId = Number(req.params.recipientId);
  const chats = JSON.parse(fs.readFileSync(CHATS_FILE, "utf8"));

  // Encontrar o chat que inclui o senderId e recipientId
  const chat = chats.find(
    (c) =>
      c.participants.includes(senderId) &&
      c.participants.includes(recipientId)
  );

  // Enviar o histórico de mensagens ou uma lista vazia se não houver mensagens
  res.json(chat ? chat.messages : []);
});

io.on("connection", (socket) => {
  socket.on("sendMessage", (message) => {
    const chats = JSON.parse(fs.readFileSync(CHATS_FILE, "utf8"));
    let chat = chats.find(
      (c) =>
        c.participants.includes(message.senderId) &&
        c.participants.includes(message.recipientId)
    );

    if (!chat) {
      chat = {
        id: Date.now(),
        participants: [message.senderId, message.recipientId],
        messages: [],
      };
      chats.push(chat);
    }

    chat.messages.push(message);
    fs.writeFileSync(CHATS_FILE, JSON.stringify(chats, null, 2));
    io.emit("newMessage", message);
  });
});

app.get('/profile', isAuthenticated, (req, res) => {
    const userId = req.session.userId;
    // Ler o arquivo users.json
    fs.readFile(path.join(__dirname, 'users.json'), 'utf8', (err, data) => {
        if (err) {
            res.status(500).send("Erro ao ler arquivo de usuários");
            return;
        }

        // Converter o arquivo JSON em objeto
const users = loadUsers();
const ids = loadIds();
        // Encontrar o usuário com base no ID
        const user = users.find(u => u.id == userId);

        if (!user) {
            return res.status(404).send("Usuário não encontrado");
        }
        
        const formatLegend = (legend) => {
    if (!legend) return '';
    return legend
        .replace(/@([a-zA-Z0-9_.]+)/g, (match, username) => {
            const mentionedUser = users.find(u => u.username === username);
            if (mentionedUser) {
                return `<a href="/profile-user/${mentionedUser.username}" style="color: #639af2; text-decoration: none;">${match}</a>`;
            }
            return match;
        })
        .replace(/\n/g, '<br>'); // Substitui quebra de linha por <br>
};
        
         
        
let verificationBadge = getVerificationBadge(user.verifications);

        res.send(`
            <html>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
                    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
                    <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Perfil - ${user.name}</title>
                    <style>
                        body {
            margin: 0;
            padding: 0;
            background-color: #000;
            font-family: Arial, sans-serif;
            color: #fff;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 15px;
            border-bottom: 1px solid #333;
        }
        .header span {
            font-size: 18px;
        }
        .header .profile-name {
            display: flex;
            align-items: center;
        }
        .header .profile-name svg {
            margin-left: 5px;
            cursor: pointer;
        }   
        .profile {
            padding: 20px 15px;
            display: flex;
            align-items: center;
        }
        .profile-pic {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            border: 2px solid #fff;
            margin: 7px;
        }
        .profile-info {
            margin-left: 15px;
            flex-grow: 1;
        }
        .profile-info h1 {
            font-size: 16px;
            margin: -20px 0 0;
        }
        .profile-info p {
            margin: 2px 0;
            font-size: 14px;
            color: #aaa;
        }
        .profile-info p2 {
            margin: 2px 0;
            font-size: 14px;
            color: #639af2;
        }
        .stats {
            display: flex;
            justify-content: space-between;
            margin-top: 0px;
            gap: 20px;
            margin: 0px;
            padding: 7px;
        }
        .stats div {
            text-align: center;
        }
        .stats div strong {
            display: block;
            font-size: 16px;
        }
        .buttons {
            display: flex;
            justify-content: space-around;
            border-bottom: 1px solid #333;
            margin-top: -8px;
            padding: 15px;
        }
        .buttons button {
            background: none;
            border: 1px solid #555;
            border-radius: 5px;
            padding: 5px 10px;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
        }
        .buttons button:hover {
            background-color: #333;
        }
        .highlights {
            display: flex;
            justify-content: space-evenly;
            margin: 20px 0;
        }
        .highlights img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 2px solid #333;
        }
 .posts {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-start;
    margin-top: 10px;
    padding: 0;
    gap: 3px;
}

.posts a {
    display: block; /* Faz o <a> se comportar como bloco */
    width: calc((100% - 10px) / 3); /* Garante o alinhamento com as imagens */
    aspect-ratio: 1 / 1; /* Mantém a proporção quadrada */
}

.posts img {
    width: 100%; /* Faz a imagem ocupar todo o espaço do <a> */
    height: 100%; /* Garante que a imagem preencha o espaço */
    object-fit: cover; /* Ajusta o conteúdo dentro do espaço */
    border-radius: 0px;
}
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0);
            backdrop-filter: blur(10px);
            justify-content: center;
            align-items: center;
            z-index: 999; /* Garante que a pop-up fique sobre outros elementos */
        }
        .popup-content {
            background-color: #1c1c1c;
            width: 80%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            padding: 20px;
            position: relative;
            margin: 0 auto; /* Garantindo que fique centralizado */
        }
        .popup-content h1 {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
        .popup-content h2 {
            font-size: 20px;
            margin-bottom: -25px;
        }
        .popup-content .profile-img {
           width: 100px;
           height: 100px;
           border-radius: 50%;
           margin-bottom: -10px;
           margin-top: -30px;
        }

        .popup-content .verified {
            color: #4aa1ec;
            font-size: 18px;
        }

        .popup-content .details {
            border-top: 1px solid #333;
            padding-top: 20px;
            margin-top: 20px;
        }

        .popup-content .detail {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .popup-content .icon {
            font-size: 24px;
            color: white;
            margin-right: 15px;
        }

        .close-popup {
            position: absolute;
            top: 10px;
            right: 10px;
            color: #fff;
            font-size: 24px;
            cursor: pointer;
        }
                    .footer-menu {
                position: fixed;
                bottom: 0;
                left: 0;
                width: 100%;
                background-color: #121212;
                border-top: 1px solid #333;
                display: flex;
                justify-content: space-around;
                align-items: center;
                padding: 10px 0;
                z-index: 1000;
            }
            .footer-menu img {
                width: 28px;
                height: 28px;
            }
                    </style>
                </head>
                <body>
                
                    <div class="footer-menu">
        <a href="/" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/home.png" alt="Home Icon">
            </a>
            
            <a href="/search" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/search--v1.png" alt="Search Icon">
          </a>
              <a href="/post" >
  <img src="https://img.icons8.com/ios-filled/50/ffffff/plus-math.png" alt="Add Icon">
</a>
            
            
           <a href="/profile" >
             <img src="${user.photo}" alt="Profile Icon" style="border-radius: 50%;">
             </a>
        </div>
                
                    <div class="header">
                      <div class="profile-name" onclick="showPopup(event)">
                            <span>${user.username}</span>
                            ${verificationBadge}
                        </div>
                        <span><i class="fas fa-cog settings-icon"></i></span>
                    </div>

                    <div class="profile">
                        <img src="${user.photo}" alt="Perfil" class="profile-pic">
                    
                        <div class="stats">
                            <div>
                                <strong>${user.posts.length}</strong>
                                <span>Posts</span>
                            </div>
                            <div>
<strong>
${ids.ids.includes(user.id) ? 
  (user.followersB >= 1_000_000 ? (user.followersB / 1_000_000).toFixed(1) + 'M' :
    user.followersB >= 1_000 ? (user.followersB / 1_000).toFixed(1) + 'K' :
    user.followersB) 
  : 
  (user.followers.length >= 1_000_000 ? (user.followers.length / 1_000_000).toFixed(1) + 'M' :
    user.followers.length >= 1_000 ? (user.followers.length / 1_000).toFixed(1) + 'K' :
    user.followers.length)}
</strong>
                                <span>Seguidores</span>
                            </div>
                            <div>
                                <strong>${user.following.length}</strong>
                                <span>Seguindo</span>
                            </div>
                        </div>
                    </div>
                    <div class="profile-info">
                        <h1>${user.name}</h1>
                        <p2>${user.category? user.category:''}</p>
                        <p>${formatLegend(user.legend || '')}</p>
                    </div>
                    <div class="buttons">
                        <button>Painel profissional</button>
                        <a href="/edit-profile" >
                        <button>Editar perfil</button>
                        </a>
                        <button>Compartilhar</button>
                    </div>
<div class="posts">
    ${user.posts
        .sort((a, b) => {
            // Extrair a data e hora do formato "Dia 05/01/2025 às 22:22"
            const getDateTime = post => {
                const regex = /dia (\d{2})\/(\d{2})\/(\d{4}) às (\d{2}):(\d{2})/;
                const [, day, month, year, hour, minute] = post.DateTime.match(regex);
                return new Date(`${year}-${month}-${day}T${hour}:${minute}:00`);
            };
            
            return getDateTime(b) - getDateTime(a);
        })
        .map(post => {
            // Verifica a extensão do arquivo para identificar se é um vídeo
            const fileExtension = post.Post.split('.').pop().toLowerCase();
            
            // Se for um vídeo
            if (['mp4', 'webm', 'ogg'].includes(fileExtension)) {
                return `
                <a href="/posti/${post.postId}" style="position: relative; display: block;">
                    <!-- Imagem de thumbnail do vídeo com botão de play -->
                    <img src="./uploads/play.png" alt="Thumbnail" 
                         style="width: 100%; height: 100%; object-fit: cover; border-radius: 0px;">
                    <!-- Botão de Play -->
                    <div style="position: absolute; top: 50%; left: 50%; transform: translate(0%, 0%);
                                background: rgba(0, 0, 0, 0); padding: 15px; border-radius: 50%; 
                                color: white; font-size: 24px; display: flex; justify-content: center; align-items: center;">
                       
                    </div>
                </a>
                `;
            } else {
                // Se for uma imagem
                return `
                <a href="/posti/${post.postId}">
                    <img src="${post.Post}" alt="Post Image" style="width: 100%; height: 100%; object-fit: cover;">
                </a>
                `;
            }
        }).join('')}
</div>
                    <!-- Popup -->
                    <div class="popup-overlay" id="popupOverlay" onclick="closePopup(event)">
                        <div class="popup-content">
                            <h1>Sobre esta conta</h1>
                            <div class="profile" style="display: flex; flex-direction: column; align-items: center;">
                                <img src="${user.photo}" alt="Perfil" class="profile-img">
                                <h2>${user.username}
                                    ${verificationBadge}
                                </h2>
                            </div>
                            <div class="details">
                                <div class="detail">
                                    <i class="fas fa-calendar-alt icon"></i>
                                    <p><strong>Data de entrada</strong><br>Janeiro de 2025</p>
                                </div>
                                <div class="detail">
                                    <i class="fas fa-map-marker-alt icon"></i>
                                    <p><strong>Conta situada em</strong><br>${user.country}</p>
                                </div>
<div class="detail">
    ${verificationBadge ? `
        <div class="detail" style="display: flex; align-items: center; gap: 2px;">
            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" 
                width="2em" height="2em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" 
                data-icon="ic:baseline-verified">
                <path fill="white" stroke="" stroke-width="1" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path>
            </svg>
            <p><strong>Verificado</strong><br></p>
        </div>
    ` : ''}
</div>

                    <script>
                        function showPopup(event) {
                            event.stopPropagation();
                            document.getElementById("popupOverlay").style.display = "flex";
                        }

                        function closePopup(event) {
                            if (event.target === document.getElementById("popupOverlay")) {
                                document.getElementById("popupOverlay").style.display = "none";
                            }
                        }
                    </script>
                </body>
            </html>
        `);
    });
  })
  
app.use('/uploads', express.static('uploads'));

app.get('/post', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'post.html'));
});

app.post('/post', isAuthenticated, upload.single('file'), (req, res) => {
    const userId = req.session.userId;
    const { description } = req.body;
    const fileUrl = req.file ? `/uploads/${req.file.filename}` : null;

    if (!fileUrl) {
        return res.status(400).send("<script>alert('Foto/Vídeo/Gif são obrigatórios.'); window.history.back();</script>");
    }

    const users = loadUsers();
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send("<script>alert('Usuário não encontrado.'); window.history.back();</script>");
    }

    const now = new Date();
    const formattedDate = `dia ${now.getDate().toString().padStart(2, '0')}/${(now.getMonth() + 1).toString().padStart(2, '0')}/${now.getFullYear()} às ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    const newPost = {
        postId: Date.now(),
        Post: fileUrl,
        LikesB: "0",
        ComentsB: "0",
        Likes: [],
        Coments: [],
        Description: description ? description : "",
        DateTime: formattedDate
    };

    user.posts.push(newPost);

    fs.writeFileSync('users.json', JSON.stringify(users, null, 2));

    // Redireciona com uma query string indicando sucesso
    res.redirect('/?message=Post criado com sucesso!');
});

app.get('/notifications', isAuthenticated, (req, res) => {
const users = loadUsers();
const userId = req.session.userId;
const username = users.find(u => u.id === userId).username

  // Encontrar o usuário pelo username
  const currentUser = users.find(user => user.username === username);

  if (!currentUser) {
    return res.status(404).send('<h1>Usuário não encontrado.</h1>' + username);
  }
  const agora = new Date();
const dia = String(agora.getDate()).padStart(2, '0');
const mes = String(agora.getMonth() + 1).padStart(2, '0'); // Meses começam do zero
const ano = agora.getFullYear();
const horas = String(agora.getHours()).padStart(2, '0');
const minutos = String(agora.getMinutes()).padStart(2, '0');

const dataHora = `${dia}/${mes}/${ano} às ${horas}:${minutos}`;

const mentionedByLegend = users.filter(user => 
    user.legend.match(/@(\w+)/g)?.some(mention => mention.replace('@', '') === currentUser.username)
  );

const mentionedInPosts = users.flatMap(user => 
    user.posts.map(post => {
      const mentions = post.Description.match(/@(\w+)/g) || [];
      return mentions.some(mention => mention.replace('@', '') === currentUser.username) 
        ? { author: user, post } 
        : null;
    }).filter(Boolean)
  );
  
    res.send(`
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">      
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
<title>Notificações</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #121212;
                color: #ffffff;
                margin: 0;
                padding: 0;
            }
            .container {
                padding: 16px;
            }
            .notification {
                display: flex;
                align-items: center;
                padding: 12px 0;
                border-bottom: 1px solid #333;
            }
            .play-icon {
                border-radius: 50px;
                width: 50px;
                height: 50px;
                margin-right: 12px;
            }
            .text {
                flex-grow: 1;
            }
            .thumbnail {
                width: 50px;
                height: 50px;
                border-radius: 4px;
            }
                }
    .tab-menu {
      display: flex;
      justify-content: space-around;
      background: #111;
      padding: 10px 0;
    }
    .tab-menu button {
      background: none;
      border: none;
      color: #fff;
      font-size: 24px;
      cursor: pointer;
    }
   .tab-menu button.active {
      background: linear-gradient(45deg, #1298ff, #bc12ff);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-fill-color: transparent;
    }
    .tab-content {
      display: none;
      padding: 2px;
    }
    .tab-content.active {
      display: block;
    }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Notificações</h1>
            <div class="tab-menu">
    <button id="followers-tab" class="active"><i class="fas fa-user-plus"></i></button>
    <button id="likes-tab"><i class="fas fa-heart"></i></button>
    <button id="mentions-tab"><i class="fas fa-at"></i></button>
  </div>
  <div id="notifications">
  <div id="followers" class="tab-content active">
${currentUser.followers && currentUser.followers.length > 0 ? currentUser.followers.map(followerId => {
    // Encontra os dados do usuário correspondente ao followerId
    const followerData = users.find(user => user.id === followerId);
    
    // Extrai o nome de usuário (username) ou usa "Desconhecido" como fallback
    const followerUsername = followerData ? followerData.username : "Desconhecido";
    
let verificationBadge = getVerificationBadge(followerData.verifications);
    
    return `
        <div class="notification">
        <a href="/profile-user/${followerUsername}" style="text-decoration: none; color: #fff;">
            <img src="${followerData ? followerData.photo : './uploads/default.png'}" alt="${followerUsername}"class="play-icon">
            <div class="text"><strong>${followerUsername} ${verificationBadge}</a></strong> começou a seguir você.</div>
        </div>`;
}).join(''):''}
 </div>

  <div id="likes" class="tab-content">
${currentUser.posts && currentUser.posts.length > 0 ? currentUser.posts.flatMap(post => post.Likes.map(likerUsername => {
    // Encontra os dados do usuário correspondente ao likerUsername
    const likerData = users.find(user => user.id === likerUsername);

    // Extrai o username ou usa "Desconhecido" como fallback
    const likerDisplayName = likerData ? likerData.username : "Desconhecido";
    
let verificationBadge = getVerificationBadge(likerData.verifications);

    return `
        <div class="notification">
        <a href="/profile-user/${likerDisplayName}" style="text-decoration: none; color: #fff;">
            <img src="${likerData ? likerData.photo : './uploads/default.png'}" alt="${likerDisplayName}" class="play-icon">           
            <div class="text"><strong>${likerDisplayName} ${verificationBadge}</a></strong> curtiu seu post.</div>
            ${(() => {
                const fileExtension = post.Post.split('.').pop().toLowerCase();
                if (['mp4', 'webm', 'ogg'].includes(fileExtension)) {
                    return `
                        <a href="/posti/${post.postId}" style="position: relative; display: block;" class="thumbnail">
                            <img src="./uploads/play.png" alt="Thumbnail" class="thumbnail">
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(0%, 0%); background: rgba(0, 0, 0, 0); padding: 15px; border-radius: 50%; color: white; font-size: 24px; display: flex; justify-content: center; align-items: center;">
                               
                            </div>
                        </a>
                    `;
                } else {
                    return `
                        <a href="/posti/${post.postId}">
                            <img src="${post.Post}" alt="Post Image" class="thumbnail">
                        </a>
                    `;
                }
            })()}
        </div>`;
})).join('') : ''}
 </div>

  <div id="mentions" class="tab-content">
${mentionedByLegend.length > 0 ? mentionedByLegend.map(mentionedUser => {
let verificationBadge = getVerificationBadge(mentionedUser.verifications);
return `
        <div class="notification">
            <a href="/profile-user/${mentionedUser.username}" style="text-decoration: none; color: #fff;">
                <img src="${mentionedUser.photo}" alt="${mentionedUser.username}" class="play-icon">
                <div class="text"><strong>${mentionedUser.username} ${verificationBadge}</a></strong> te mencionou na biografia.</div>
        </div>
    `;
}).join('') : ''}
            ${mentionedInPosts.length > 0 ? mentionedInPosts.map(({ author, post }) => {
            
let verificationBadge = getVerificationBadge(author.verifications);
            
              const fileExtension = post.Post.split('.').pop().toLowerCase();
              const isVideo = ['mp4', 'webm', 'ogg'].includes(fileExtension);
              return `
                <div class="notification">
                    <a href="/profile-user/${author.username}" style="text-decoration: none; color: #fff;">
                        <img src="${author.photo}" alt="${author.username}" class="play-icon">
                        <div class="text">
                            <strong>${author.username} ${verificationBadge}</a></strong> te mencionou em um post.
                        </div>
                    ${isVideo 
                      ? `
                        <a href="/posti/${post.postId}" class="video-thumbnail">
                            <img src="./uploads/play.png" alt="Thumbnail" class="thumbnail">
                            <div class="video-play-button"></div>
                        </a>
                      `
                      : `
                        <a href="/posti/${post.postId}">
                            <img src="${post.Post}" alt="Post Image" class="thumbnail">
                        </a>
                      `
                    }
                </div>`;
            }).join('') : ''}
             </div>
        </div>
          <script>
    // Código do usuário
    const abas = document.querySelectorAll('.tab-menu button');
    const conteudos = document.querySelectorAll('.tab-content');

    abas.forEach(aba => {
      aba.addEventListener('click', () => {
        // Remove a classe ativa de todas as abas e conteúdos
        abas.forEach(btn => btn.classList.remove('active'));
        conteudos.forEach(content => content.classList.remove('active'));

        // Adiciona a classe ativa na aba e conteúdo correspondentes
        aba.classList.add('active');
        const idAba = aba.id.replace('-tab', '');
        document.getElementById(idAba).classList.add('active');
      });
    });
  </script>
    </body>
    </html>
    `);
});

app.get('/ko', (req, res) => {
res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>Abas Personalizadas</title>
  <style>
    /* Estilos originais */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      text-align: center;

  </style>
</head>
<body>

  
    <h1>Aba de Seguidores</h1>
    <p>Conteúdo relacionado aos seguidores.</p>
 

  <div id="likes" class="tab-content">
    <h1>Aba de Curtidas</h1>
    <p>Conteúdo relacionado às curtidas.</p>
  </div>

  <div id="mentions" class="tab-content">
    <h1>Aba de Menções</h1>
    <p>Conteúdo relacionado às menções.</p>
  </div>


</body>
</html>`)
})

app.get('/notify', (req, res) => {

  // Renderizar o HTML
  res.send(`
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Seguidores de ${currentUser.name}</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 20px;
    }

    #followers-count, #notifications {
      width: 300px;
      background: #fff;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      margin-bottom: 20px;
      overflow: hidden;
    }

    #followers-count h2, #notifications h2 {
      background: #007BFF;
      color: white;
      margin: 0;
      padding: 15px;
      text-align: center;
      font-size: 18px;
    }

    #followers-list, .notification {
      padding: 10px 15px;
      border-bottom: 1px solid #ddd;
    }

    .notification:last-child, #followers-list:last-child {
      border-bottom: none;
    }

    .notification strong {
      font-weight: bold;
    }
  </style>
</head>
<body>
<div id="followers-count">
  <h2>Notificações</h2>
  <div id="followers-list">
    ${
      currentUser.followers
        .map(follower => {
          // Buscar dados do seguidor pelo username
          const followerData = users.find(user => user.username === follower);
          const followerName = followerData ? followerData.name : "Desconhecido";
          return `<div class="list-item"><strong>${followerName} (${follower})</strong> começou a seguir você.</div>`;
        })
        .join('')
    }
    ${
      currentUser.posts && currentUser.posts.length > 0
        ? currentUser.posts
            .flatMap(post =>
              post.Likes.map(liker => {
                // Buscar dados do usuário que curtiu pelo username
                const likerData = users.find(user => user.username === liker);
                const likerName = likerData ? likerData.name : "Desconhecido";
                return `<div class="list-item"><strong>${likerName} (${liker})</strong> curtiu seu POST ${post.postId}.</div>`;
              })
            )
            .join('')
        : ''
    }
  </div>
</div>
</body>
</html>
  `);
});

app.get('/posti/:id', isAuthenticated, (req, res) => {
    const postId = Number(req.params.id);
    const users = loadUsers();
    const userId = req.session.userId;
    const user2 = users.find(u => u.id === userId);
    const userInfoo = user2.id;
    const ids = loadIds();
    const idc = loadIdc();
    
    fs.readFile('users.json', 'utf8', (err, data) => {
        if (err) {
            console.error('Erro ao ler o arquivo:', err);
            return res.status(500).send('Erro ao acessar os dados.');
        }

        const users = loadUsers();

        let foundPost = null;
        let userInfo = null;

        for (const user of users) {
            const post = user.posts.find(post => post.postId === postId);
            if (post) {
                foundPost = post;
                userInfo = user;
                break;
            }
        }

        if (!foundPost) {
            console.error(`Post com ID ${postId} não encontrado.`);
            return res.status(404).send('Postagem não encontrada. Verifique o ID.');
        }
        
        const formatLegend = (desc) => {
    if (!desc) return '';
    return desc
        .replace(/@([a-zA-Z0-9_.]+)/g, (match, username) => {
            const mentionedUser = users.find(u => u.username === username);
            if (mentionedUser) {
                return `<a href="/profile-user/${mentionedUser.username}" style="color: #639af2; text-decoration: none;">${match}</a>`;
            }
            return match;
        })
        .replace(/\n/g, '<br>'); // Substitui quebra de linha por <br>
};

let verificationBadge = getVerificationBadge(userInfo.verifications);

        function isVideo(url) {
            const videoExtensions = ['.mp4', '.mov', '.avi', '.mkv'];
            return videoExtensions.some(extension => url.toLowerCase().endsWith(extension));
        }

        let postContent = '';
        if (isVideo(foundPost.Post)) {
            postContent = `<video controls class="post-img">
                             <source src="${foundPost.Post}" type="video/mp4">
                             Seu navegador não suporta a tag de vídeo.
                           </video>`;
        } else {
            postContent = `<img src="${foundPost.Post}" alt="Post Image" class="post-img">`;
        }

        let likeIcon = 'https://img.icons8.com/ios-filled/50/ffffff/like--v1.png';
        let likeButtonClass = 'like-button';
        if (foundPost.Likes.includes(userId)) {
            likeIcon = 'https://img.icons8.com/ios-filled/50/ff0000/filled-like.png';
            likeButtonClass = 'liked';
        }

        res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Publicação ${userInfo.name}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: auto;
            background-color: #000;
            border: 1px solid #222;
        }
        .header {
            display: flex;
            align-items: center;
            padding: 6px;
            border-bottom: 1px solid #333;
        }
        .profile {
            display: flex;
            align-items: center;
            flex: 1;
        }
        .profile-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .profile-info {
            margin-left: 10px;
            display: flex;
            align-items: center;
        }
        .username {
            font-weight: bold;
            font-size: 16px;
        }
        .follow {
            background: none;
            border: none;
            color: #1e90ff;
            font-size: 14px;
            cursor: pointer;
        }
        .content {
            text-align: center;
            margin: 10px 0;
        }
        .post-img {
            width: 100%;
            border-radius: 1px;
        }
        .footer {
            padding: 10px;
        }
        .post-actions {
            display: flex;
            align-items: center;
            gap: 40px;
        }
        .post-actions .icon-container {
            text-align: center;
        }
        .post-actions img {
            width: 24px;
            height: 24px;
        }
        .stat-text {
            font-size: 12px;
            color: #aaa;
            margin-top: 2px;
        }
        .like-button {
            cursor: pointer;
        }
         .time {
                font-size: 12px;
                color: #888;
            }
        .liked {
            filter: grayscale(0%);
        }
                    .official-account {
    display: block;
    font-size: 0.9em;
    color: gray;
    text-align: left;
    margin-top: 0px;
}
    </style>
</head>
<body>
 <div class="container">
    <header class="header">
        <div class="profile">
            <img src="${userInfo.photo}" alt="Profile Picture" class="profile-img">
            <div class="profile-info">
                <span class="username">${userInfo.username} </span>
                ${verificationBadge}
            </div>
            <small class="official-account">  ${userInfo && userInfo.type ? userInfo.type : ""}</small>
        </div>
        <button class="follow">Seguir</button>
    </header>
    <div class="content">
         ${postContent}
    </div>
    <footer class="footer">
        <div class="post-actions">
            <div class="icon-container">
                <img src="${likeIcon}" alt="Like Icon" class="${likeButtonClass}" id="like-icon-${foundPost.postId}" onclick="toggleLike(${foundPost.postId})">
       <div class="stat-text">
  ${idc.ids.includes(userInfo.id) 
    ? (
      foundPost.LikesB >= 1_000_000 
        ? (foundPost.LikesB / 1_000_000).toFixed(1) + 'M'
        : foundPost.LikesB >= 1_000 
          ? (foundPost.LikesB / 1_000).toFixed(1) + 'K'
          : foundPost.LikesB
    )
    : (
      `<span id="like-count-${foundPost.postId}">` +
      (foundPost.Likes.length >= 1_000_000 
        ? (foundPost.Likes.length / 1_000_000).toFixed(1) + 'M'
        : foundPost.Likes.length >= 1_000 
          ? (foundPost.Likes.length / 1_000).toFixed(1) + 'K'
          : foundPost.Likes.length
      ) +
      `</span>`
    )
  }
</div>         
     
            </div>
            <div class="icon-container">
                <img src="https://img.icons8.com/ios-filled/50/ffffff/speech-bubble.png" alt="Comment Icon">
                <div class="stat-text">${foundPost.Coments.length}</div>
            </div>
            <div class="icon-container">
                <img src="https://img.icons8.com/ios-filled/50/ffffff/share.png" alt="Share Icon">
            </div>
        </div>
        <div class="description">
            <p><b>${userInfo.username}</b>: ${formatLegend(foundPost.Description || '')}</p>
        </div>
        <span class="time">Postado no ${foundPost.DateTime}</span>
    </footer>
</div>
<script>
    function toggleLike(postId) {
        fetch('/like', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ postId: postId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const likeIcon = document.getElementById('like-icon-' + postId);
                const likeText = document.getElementById('like-count-' + postId);

                if (data.liked) {
                    likeIcon.src = 'https://img.icons8.com/ios-filled/50/ff0000/filled-like.png';
                    likeIcon.classList.add('liked');
                } else {
                    likeIcon.src = 'https://img.icons8.com/ios-filled/50/ffffff/like--v1.png';
                    likeIcon.classList.remove('liked');
                }
                likeText.textContent = data.likeCount;
            }
        })
        .catch(error => {
            console.error('Erro ao curtir o post:', error);
        });
    }
</script>
</body>
</html>
        `);
    });
});


app.post("/like", isAuthenticated, (req, res) => {
  const { postId } = req.body;
  const users = loadUsers();
  const userId = req.session.userId;
  const ids = loadIds();

  if (!userId) {
    return res.status(404).json({ success: false, message: "UsuÃ¡rio nÃ£o encontrado" });
  }

  let foundPost = null;

  for (const user of users) {
    foundPost = user.posts.find(post => post.postId === postId);
    if (foundPost) {
      if (foundPost.Likes.includes(userId)) {
        foundPost.Likes = foundPost.Likes.filter(user => user !== userId); // Remove o like
      } else {
        foundPost.Likes.push(userId); // Adiciona o like
      }
      break;
    }
  }

  if (!foundPost) {
    return res.status(404).json({ success: false, message: "Post nÃ£o encontrado" });
  }

  writeToFileSafely("users.json", users, (err) => {
    if (err) {
      console.error("Erro ao salvar o arquivo:", err);
      return res.status(500).json({ success: false, message: "Erro ao salvar o arquivo" });
    }

    res.json({
      success: true,
      liked: foundPost.Likes.includes(userId),
      likeCount: foundPost.Likes.length,
    });
  });
});

// Outras partes do cÃ³digo permanecem inalteradas

app.get('/', isAuthenticated, (req, res) => {
  const users = loadUsers();
  const idc = loadIdc();
  
const posts = users.flatMap(user => user.posts);
const shuffledPosts = posts.sort(() => 0.5 - Math.random());

const userId = req.session.userId;
const user2 = users.find(u => u.id === userId);

const postCommentsMap = users.reduce((map, user) => {
  user.posts.forEach(post => {
    map[post.postId] = post.Coments || [];
  });
  return map;
}, {});

let postsHtml = shuffledPosts.map(post => {
  const user = users.find(u => u.posts.some(p => p.postId === post.postId));
  
  const formatLegend = (desc) => {
    if (!desc) return '';
    return desc
        .replace(/@([a-zA-Z0-9_.]+)/g, (match, username) => {
            const mentionedUser = users.find(u => u.username === username);
            if (mentionedUser) {
                return `<a href="/profile-user/${mentionedUser.username}" style="color: #639af2; text-decoration: none;">${match}</a>`;
            }
            return match;
        })
        .replace(/\n/g, '<br>'); // Substitui quebra de linha por <br>
};
  
let verificationBadge = getVerificationBadge(user.verifications);

  let mediaHtml = '';
  if (post.Post.endsWith('.jpg') || post.Post.endsWith('.jpeg') || post.Post.endsWith('.png') || post.Post.endsWith('.gif') || post.Post.endsWith('.webp')) {
    mediaHtml = `<img src="${post.Post}" alt="Post Image" style="max-width: 100%; height: auto;">`;
  } else if (post.Post.endsWith('.mp4') || post.Post.endsWith('.webm') || post.Post.endsWith('.ogg')) {
    mediaHtml = `<video controls style="max-width: 100%; height: auto;">
                  <source src="${post.Post}" type="video/mp4">
                  Seu navegador não suporta o vídeo.
                </video>`;
  } else {
    mediaHtml = 'Arquivo não suportado';
  }
  
let commentsHtml = '';
const postComments = postCommentsMap[post.postId];

if (postComments && Array.isArray(postComments)) {
  commentsHtml = postComments.map(comment => {
    const commenter = users.find(u => u.id === comment.user) || { username: 'Desconhecido', photo: './uploads/default.png' };

    // Substituí caracteres especiais no comentário e nome do usuário para evitar problemas de HTML
    const safeComment = comment.comment.replace(/'/g, "\\'").replace(/"/g, '\\"');
    const safeUsername = commenter.username.replace(/'/g, "\\'").replace(/"/g, '\\"');

    return `
      <div class="comment" 
           onmousedown="openCommentOptions()">
        <img src="${commenter.photo}" alt="Avatar" class="avatar">
        <div class="comment-text">
          <span class="username">${commenter.username}</span>
          <span class="time">${new Date(comment.date).toLocaleString('pt-BR')}</span>
          <p>${comment.comment}</p>
        </div>
      </div>`;
  }).join('');
}

let commentInputHtml = `

`;



  return `
    <div class="post">  
      <div class="post-header">
      <a href="/profile-user/${user.username}" style="text-decoration: none; color: #fff;">
        <img src="${user.photo ? user.photo : "./uploads/default.png"}" alt="${user.name}">
        <div class="user-info">
          <div class="name-container">
            <span>${user.username}</span>
            ${verificationBadge}
          </div>
          <small class="official-account">${user && user.type ? user.type : ""}</small>
          </a>
        </div>
      </div>
      

${mediaHtml}
          
      <div class="post-actions">
                 <div class="icon-container">
           <img src="${post.Likes.includes(user2.id) ? 'https://img.icons8.com/ios-filled/50/ff0000/filled-like.png' : 'https://img.icons8.com/ios-filled/50/ffffff/like--v1.png'}" alt="Like Icon" class="like-button" id="like-icon-${post.postId}" onclick="toggleLike(${post.postId})">
                                    
<div class="stat-text">
  ${idc.ids.includes(user.id) 
    ? (
      post.LikesB >= 1_000_000 
        ? (post.LikesB / 1_000_000).toFixed(1) + 'M'
        : post.LikesB >= 1_000 
          ? (post.LikesB / 1_000).toFixed(1) + 'K'
          : post.LikesB
    )
    : (
      `<span id="like-count-${post.postId}">` +
      (post.Likes.length >= 1_000_000 
        ? (post.Likes.length / 1_000_000).toFixed(1) + 'M'
        : post.Likes.length >= 1_000 
          ? (post.Likes.length / 1_000).toFixed(1) + 'K'
          : post.Likes.length
      ) +
      `</span>`
    )
  }
</div>
                                    
          </div>
        

 <div class="icon-container" onclick="togglePopup(${post.postId})">
  <img src="https://img.icons8.com/ios-filled/50/ffffff/speech-bubble.png" alt="Comment Icon">
  <div class="stat-text">${post.Coments.length}</div>
</div>

<div class="popup-overlay" id="popup-${post.postId}">
  <div class="popup-content" id="popupContent-${post.postId}">
    <div class="popup-header">
      Comentários
      <span class="close-btn" onclick="closePopup(${post.postId})">×</span>
    </div>
    
    <div class="comments">
      ${commentsHtml}
              <div class="comment2">
          <div class="comment-text">
          </div>
        </div>
      <div class="add-comment hidden" id="addComment-${post.postId}">
        <input 
          type="text" 
          id="comment-input-${post.postId}" 
          placeholder="Digite seu comentário..." 
          class="comment-input">
        <button onclick="addComment(${post.postId})" class="comment-button">Enviar</button>
      </div>
    </div>
  </div>
</div> 

  
        <div class="icon-container">
          <img src="https://img.icons8.com/ios-filled/50/ffffff/share.png" alt="Share Icon">
        </div>
      </div>
      <div class="post-stats">
        <p class="description2">
          <b>${user.username}</b>: ${formatLegend(post.Description || '')}
        </p>
        <span class="time">Postado no ${post.DateTime}</span>
      </div>
    </div>
  `;
}).join('');

  res.send(`
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
        <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Mexus - Home</title>
        <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #000;
                color: #fff;
                padding-bottom: 30px;
            }
             .popup-overlay {
      position: fixed;
      top: 100%;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 9999;
      transition: top 0.3s ease-in-out;
    }
    .popup-content {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 50%;
  background: black; /* Alterado para fundo preto */
  border-radius: 20px 20px 0 0;
  overflow-y: auto;
  transition: height 0.3s ease-in-out;
  color: white; /* Texto branco */
}

.popup-content.fullscreen {
  height: 100%;
  border-radius: 0;
}

.popup-header {
  padding: 10px;
  background: #333; /* Fundo do cabeçalho mais escuro */
  border-bottom: 1px solid #444; /* Borda escura */
  text-align: center;
  font-weight: bold;
  position: sticky;
  top: 0;
  z-index: 10;
  color: white; /* Texto branco */
}

.popup-header .close-btn {
  position: absolute;
  right: 15px;
  top: 10px;
  font-size: 20px;
  cursor: pointer;
  color: white; /* Texto branco */
}

.comments {
  padding-bottom: 80px;
  box-sizing: border-box;
  padding: 10px;
  color: white; /* Texto branco */
}

.add-comment {
  position: fixed;
  bottom: 0px; /* Ajuste a distância da parte inferior */
  left: 0;
  right: 0;
  background: #333;
  padding: 10px;
  display: flex;
  align-items: center;
  box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.2);
  transition: top 0.3s ease-in-out;
}

.hidden {
  display: none; /* Esconde o campo de comentários inicialmente */
}

.comment-input {
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-right: 10px;
  background-color: #1c1c1e;
  color: #fff
}

.comment-button {
  padding: 10px 15px;
  background: #007BFF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: top 0.3s ease-in-out;
}

.adjust-position-btn {
  position: absolute;
  top: 5px;
  right: 10px;
  padding: 5px 10px;
  background: #007BFF;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: top 0.3s ease-in-out;
}

.comment {
  display: flex;
  align-items: flex-start;
  margin-bottom: 15px;
  padding: 10px 0;
  border-bottom: 1px solid #333;
}

.comment2 {
  display: flex;
  align-items: flex-start;
  margin-bottom: 15px;
  padding: 10px 0;
}

.avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  margin-right: 10px;
}

.comment-text {
  flex: 1;
}

.username {
  font-weight: bold;
  margin-right: 10px;
}

.time {
  font-size: 12px;
  color: #888;
}

.likes {
  display: flex;
  align-items: center;
  font-size: 14px;
  color: #888;
}

.heart {
  margin-right: 5px;
  color: red;
}


            .official-account {
    display: block;
    font-size: 0.9em;
    color: gray;
    text-align: left;
    margin-top: 0px;
}
                 header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 10px 15px;
                background-color: #121212;
                border-bottom: 1px solid #333;
            }
            header img {
                height: 25px;
            }
            .icons {
                display: flex;
                gap: 15px;
            }
            .icons img {
                width: 24px;
                height: 24px;
            }
            .stories {
                display: flex;
                overflow-x: auto;
                padding: 10px 0;
                border-bottom: 1px solid #333;
            }
            .story {
                margin: 0 10px;
                text-align: center;
            }
            .story img {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                border: 2px solid #f5397d;
            }
            .story span {
                display: block;
                margin-top: 5px;
                font-size: 12px;
                color: #aaa;
            }
            .post {
                margin: 5px 5px;
                border-bottom: 1px solid #333;
                
            }
            .post img {
                width: 100%;
                margin-left: 1px;
            }
            .post-header, .post-actions, .post-stats {
                padding: 10px 15px;
            }
            .post-header {
                display: flex;
                align-items: center;
            }
            .post-header img {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                margin-right: 10px;
            }
            .post-header .user-info {
                display: flex;
                flex-direction: column;
            }
            .post-header .name-container {
                display: flex;
                align-items: center;
                font-weight: bold;
            }
            .iconify {
                margin-left: 5px;
                cursor: pointer;
            }
            .post-actions {
            margin-left: 8px;
                display: flex;
                align-items: center;
                gap: 40px;
            }
            .post-actions .icon-container {
                text-align: center;
            }
            .post-actions img {
                width: 24px;
                height: 24px;
            }
            .post-actions .stat-text {
                margin-left: 0px;
                font-size: 10px;
                color: #aaa;
                margin-top: 2px;
            }
            .post-stats {
                padding: 10px 12.5px;
            }
            .post-stats .description {
                display: flex;
                font-size: 15px;
                align-items: center;
                margin-top: -10px;
                margin-bottom: 1px;
            }
            .time {
                font-size: 12px;
                color: #888;
            }
            .post-stats .description .iconify {
                margin-left: 5px;
            }
            .description-text {
                line-height: 1.5;
                font-size: 1px;
                word-wrap: break-word;
                display: inline-block;
                margin: 0;
            }
            .footer-menu {
                position: fixed;
                bottom: 0;
                left: 0;
                width: 100%;
                background-color: #121212;
                border-top: 1px solid #333;
                display: flex;
                justify-content: space-around;
                align-items: center;
                padding: 10px 0;
                z-index: 1000;
            }
            .footer-menu img {
                width: 28px;
                height: 28px;
            }
            .description2 {
                font-size: 13px;
                line-height: 1.4;
                margin-top: -10px;
                margin-bottom: 1px;
            }
            .mexus-logo {
    font-family: 'Brush Script MT', cursive; /* Usa uma fonte cursiva */
    font-size: 24px; /* Ajusta o tamanho do texto */
    color: #fff; /* Cor branca para o texto */
    font-weight: bold; /* Negrito para destacar */
    text-shadow: 0px 1px 5px rgba(0, 0, 0, 0.5); /* Sombra para destaque */
}
        </style>
    </head>
    <body>
        <header>
        <a href="/" style="text-decoration: none; color: #fff;">
           <span class="mexus-logo">Mexus</span>
            </a>
            <div class="icons">
                <a href="/notifications" >
  <img src="https://img.icons8.com/ios-filled/50/ffffff/appointment-reminders.png" alt="Notification Icon">
</a>
              <a href="/chats" >
                <img src="https://img.icons8.com/ios-filled/50/ffffff/speech-bubble.png" alt="Message Icon">
             </a>   

            </div>
        </header>
        <div class="stories">
            <div class="story">
                <img src="${user2.photo}" alt="Story">
                <span>Seu Story</span>
            </div>
            <div class="story">
            <a href="/profile-user/mexus">
                <img src="./uploads/mexus.png" alt="Story">
                 </a>
                <span>Mexus</span>
            </div>
        </div>
        <div class="posts">
            ${postsHtml}
        </div>
        <div class="footer-menu">
        <a href="/" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/home.png" alt="Home Icon">
            </a>
            
            <a href="/search" >
            <img src="https://img.icons8.com/ios-filled/50/ffffff/search--v1.png" alt="Search Icon">
          </a>
              <a href="/post" >
  <img src="https://img.icons8.com/ios-filled/50/ffffff/plus-math.png" alt="Add Icon">
</a>
            
            
           <a href="/profile" >
             <img src="${user2.photo}" alt="Profile Icon" style="border-radius: 50%;">
             </a>
        </div>

        
        <script>
     
     function openCommentOptions() {
  // Fecha outras popups abertas antes de abrir uma nova
  closeAllCommentOptions();

  // Adiciona o fundo desfocado
  const popupOverlay = document.createElement("div");
  popupOverlay.classList.add("popup-overlay-blur");
  popupOverlay.setAttribute("id", "comment-overlay");
  document.body.appendChild(popupOverlay);

  // Cria a popup de opções com base nos dados do comentário
  const optionsPopup = document.createElement("div");
  optionsPopup.classList.add("comment-options");
  optionsPopup.setAttribute("id", "comment-options");
  optionsPopup.innerHTML = \`
    <ul>
      <li onclick="addToStory()">Adicionar ao story</li>
      <li onclick="reportComment()">Denunciar</li>
      <li onclick="blockAccount()">Bloquear conta</li>
    </ul>
  \`;

  document.body.appendChild(optionsPopup);
  optionsPopup.style.display = "block";

  // Fecha a popup ao clicar fora dela
  popupOverlay.addEventListener("click", () => closeAllCommentOptions());
}

function closeAllCommentOptions() {
  const popupOverlay = document.getElementById("comment-overlay");
  const optionsPopup = document.getElementById("comment-options");

  if (popupOverlay) popupOverlay.remove();
  if (optionsPopup) optionsPopup.remove();
}

function addToStory() {
  alert("Comentário  adicionado ao story!");
  closeAllCommentOptions();
}

function reportComment() {
  alert("omentário denunciado!");
  closeAllCommentOptions();
}

function blockAccount() {
  alert("Conta bloqueada!");
  closeAllCommentOptions();
}
     
function togglePopup(postId) {
  const popup = document.getElementById("popup-"+postId);
  const addComment = document.getElementById("addComment-"+postId);

  popup.style.top = "0";
  addComment.classList.remove("hidden"); // Torna o campo de entrada visível
  document.body.style.overflow = "hidden";

  // Inicializar os eventos de deslizar
  handleTouchEvents(postId);
}

function closePopup(postId) {
  const popup = document.getElementById("popup-"+postId);
  const addComment = document.getElementById("addComment-"+postId);

  popup.style.top = "100%";
  addComment.classList.add("hidden"); // Esconde o campo de entrada
  document.body.style.overflow = "auto";
}

function handleTouchEvents(postId) {
  const popupContent = document.getElementById("popupContent-"+postId);
  let isFullscreen = false; // Indica se está em tela cheia
  let isMinimized = false; // Indica se está no tamanho reduzido
  let startY = 0;
  let currentY = 0;

  popupContent.addEventListener("touchstart", (e) => {
    startY = e.touches[0].clientY;
  });

  popupContent.addEventListener("touchmove", (e) => {
    currentY = e.touches[0].clientY;
  });

  popupContent.addEventListener("touchend", () => {
    const deltaY = currentY - startY;

    if (deltaY < -50) {
      // Deslizar para cima
      if (!isFullscreen) {
        // Mudar para tela cheia
        popupContent.classList.add("fullscreen");
        isFullscreen = true;
        isMinimized = false;
      }
    } else if (deltaY > 50) {
      // Deslizar para baixo
      if (isFullscreen) {
        // Voltar ao tamanho inicial
        popupContent.classList.remove("fullscreen");
        isFullscreen = false;
        isMinimized = true;
      } else if (isMinimized) {
        // Fechar a popup
        closePopup(postId);
        isMinimized = false;
      }
    }
  });
}

function addComment(postId) {
  const commentInput = document.getElementById("comment-input-"+postId);
  const commentText = commentInput.value.trim();

  if (!commentText) {
    alert("Digite um comentário antes de enviar.");
    return;
  }

  fetch("/add-comment", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ postId, comment: commentText }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        alert("Comentário adicionado com sucesso!");
      } else {
        alert("Erro ao adicionar comentário: " + data.message);
      }
    })
    .catch((error) => {
      console.error("Erro ao adicionar comentário:", error);
      alert("Erro ao adicionar comentário.");
    });
}

function handleTouchEvents(postId) {
  const popupContent = document.getElementById("popupContent-"+postId);
  let isFullscreen = false;

  popupContent.addEventListener("touchstart", (e) => {
    startY = e.touches[0].clientY;
  });

  popupContent.addEventListener("touchmove", (e) => {
    currentY = e.touches[0].clientY;
  });

  popupContent.addEventListener("touchend", () => {
    const deltaY = currentY - startY;

    if (deltaY < -50 && !isFullscreen) {
      popupContent.classList.add("fullscreen");
      isFullscreen = true;
    } else if (deltaY > 50 && isFullscreen) {
      popupContent.classList.remove("fullscreen");
      isFullscreen = false;
    } else if (deltaY > 50 && !isFullscreen) {
      closePopup(postId);
    }
  });
}

        function toggleLike(postId) {
            fetch('/like', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ postId: postId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const likeIcon = document.getElementById('like-icon-' + postId);
                    const likeText = document.getElementById('like-count-' + postId);

                    if (data.liked) {
                        likeIcon.src = 'https://img.icons8.com/ios-filled/50/ff0000/filled-like.png';
                        likeIcon.classList.add('liked');
                    } else {
                        likeIcon.src = 'https://img.icons8.com/ios-filled/50/ffffff/like--v1.png';
                        likeIcon.classList.remove('liked');
                    }
                    likeText.textContent = data.likeCount;
                }
            })
            .catch(error => console.error('Erro ao curtir o post:', error));
        }

  </script>
     </body>
    </html>
  `);
});    

app.post('/add-comment', (req, res) => {
    const { postId, comment } = req.body;
    const userId = req.session.userId;

    if (!userId || !postId || !comment.trim()) {
        return res.status(400).json({ success: false, message: 'Dados inválidos.' });
    }

    const users = loadUsers();
    const postOwner = users.find(u => u.posts.some(p => p.postId === postId));

    if (!postOwner) {
        return res.status(404).json({ success: false, message: 'Post não encontrado.' });
    }

    const post = postOwner.posts.find(p => p.postId === postId);
    post.Coments.push({
        user: userId,
        comment: comment.trim(),
        date: new Date().toISOString(),
    });

    saveUser(users);
    res.json({ success: true, message: 'Comentário adicionado com sucesso.' });
});

app.get('/singUp', (req, res) => {
  res.sendFile(path.join(__dirname, 'singUp.html'));
});

app.get('/edit-profilee', isAuthenticated, (req, res) => {
  const userId = req.session.userId; // Assumindo que o ID do usuário está na sessão

  const users = loadUsers();
  const user = users.find(u => u.id === userId);

  if (!user) {
    return res.status(404).send('Usuário não encontrado.');
  }

  res.json({
    name: user.name,
    username: user.username,
    legend: user.legend,
    category: user.category,
    photo: user.photo,
  });
});

app.post('/edit-profilee', isAuthenticated, upload.single('photo'), (req, res) => {
    const { name, username, legend, category } = req.body;
    const userId = req.session.userId; // Assumindo que o ID do usuário está na sessão
    const photo = req.file ? `/uploads/${req.file.filename}` : (req.body.photo.includes('./uploads/default.png') ? './uploads/default.png' : req.body.photo);

    const users = loadUsers();
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send({ success: false, message: 'Usuário não encontrado.' });
    }

    // Valida o username: deve conter apenas letras, números, . e -
    const usernameRegex = /^[a-zA-Z0-9_.]+$/;
    if (!usernameRegex.test(username)) {
        return res.status(400).send({ success: false, message: 'Nome de usuário inválido! Use apenas letras, números, . e _' });
    }

    // Converte o username para minúsculas
    const formattedUsername = username.toLowerCase();

    // Verifica se o username já está em uso por outro usuário
    const usernameExists = users.some(u => u.username === formattedUsername && u.id !== userId);
    if (usernameExists) {
        return res.status(400).send({ success: false, message: 'Esse nome de usuário já está em uso. Escolha outro.' });
    }

    // Atualizar os dados do usuário
    user.name = name || user.name;
    user.username = formattedUsername || user.username;
    user.legend = legend || user.legend;
    user.category = category || user.category;
    user.photo = photo;

    saveUser(users);

    res.send({ success: true });
});

app.get('/edit-profile', isAuthenticated, (req, res) => {
    const userId = req.session.userId; // Assumindo que o ID do usuário está na sessão

    const users = loadUsers();
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send('Usuário não encontrado.');
    }

    res.send(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Editar Perfil</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #1c1c1e;
                color: #fff;
                margin: 0;
                padding: 20px;
            }
            .container {
                max-width: 400px;
                margin: 0 auto;
                padding: 20px;
                background-color: #2c2c2e;
                border-radius: 10px;
            }
            .header {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin-bottom: 20px;
            }
            .profilee-pic {
                width: 100px;
                height: 100px;
                border-radius: 50%;
                margin-bottom: 10px;
                background-size: cover;
                background-position: center;
            }
            .form-group {
                margin-bottom: 15px;
            }
            .form-group label {
                display: block;
                margin-bottom: 5px;
            }
            .form-group input,
            textarea {
                width: 93%;
                padding: 10px;
                border: 1px solid #444;
                border-radius: 5px;
                background-color: #1c1c1e;
                color: #fff;
            }
            .form-group select {
                width: 100%;
                padding: 10px;
                border: 1px solid #444;
                border-radius: 5px;
                background-color: #1c1c1e;
                color: #fff;
            }
            #menu {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background-color: #2c2c2e;
                padding: 20px;
                border-top-left-radius: 20px;
                border-top-right-radius: 20px;
                display: none;
            }
            #menu button {
                width: 100%;
                padding: 10px;
                margin-bottom: 10px;
                border: none;
                border-radius: 5px;
                background-color: #444;
                color: #fff;
            }
            #menu button.remove {
                background-color: #d11a2a;
            }
            input[type="file"] {
                display: none;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Foto do perfil -->
            <div class="header">
                <div class="profilee-pic" id="profilee-pic" style="background-image: url('${user.photo}');"></div>
                <button id="edit-photo-button">Editar foto</button>
            </div>

            <!-- Campos de entrada -->
            <div class="form-group">
                <label for="name">Nome</label>
                <input type="text" id="name" value="${user.name}">
            </div>
            <div class="form-group">
                <label for="username">Nome de usuário</label>
                <input type="text" id="username" value="${user.username}">
            </div>
            <div class="form-group">
                <label for="legend">Biografia</label>
                <textarea id="legend" name="legend">${user.legend}</textarea>
            </div>
            <div class="form-group">
                <label for="category">Categoria</label>
                <select id="category">
                    <option value=" "> </option>
                    <option value="Blog Pessoal" ${user.category === 'Blog Pessoal' ? 'selected' : ''}>Blog Pessoal</option>
                    <option value="Artista" ${user.category === 'Artista' ? 'selected' : ''}>Artista</option>
                    <option value="Blogueiro (a)" ${user.category === 'Blogueiro (a)' ? 'selected' : ''}>Blogueiro (a)</option>
                    <option value="Empresa de Tecnologia" ${user.category === 'Empresa de Tecnologia' ? 'selected' : ''}>Empresa de Tecnologia</option>
                    <option value="Programador (a)" ${user.category === 'Programador (a)' ? 'selected' : ''}>Programador (a)</option>
                    <option value="Influenciador Digital" ${user.category === 'Influenciador Digital' ? 'selected' : ''}>Influenciador Digital</option>
                    <option value="Marca" ${user.category === 'Marca' ? 'selected' : ''}>Marca</option>
                    <option value="Gamer" ${user.category === 'Gamer' ? 'selected' : ''}>Gamer</option>
                    <option value="Pela diversão" ${user.category === 'Pela diversão' ? 'selected' : ''}>Pela diversão</option>
                </select>
            </div>
            <button id="save-button">Realizar alterações</button>
        </div>

        <!-- Menu de opções -->
        <div id="menu">
            <button id="choose-library">Escolher na Galeria</button>
            <button id="take-photo">Tirar Foto</button>
            <button id="remove-photo" class="remove">Remover Foto Atual</button>
            <button id="reset-photo">Restaurar Foto Original</button>
        </div>

        <input type="file" id="file-input" accept="image/*">

        <script>
            const editPhotoButton = document.getElementById('edit-photo-button');
            const menu = document.getElementById('menu');
            const fileInput = document.getElementById('file-input');
            const profileePic = document.getElementById('profilee-pic');
            const chooseLibrary = document.getElementById('choose-library');
            const removePhoto = document.getElementById('remove-photo');
            const resetPhoto = document.getElementById('reset-photo');
            const saveButton = document.getElementById('save-button');

            const defaultPhoto = './uploads/default.png';
            const originalPhoto = '${user.photo}';

            // Abrir menu ao clicar em "Editar foto ou avatar"
            editPhotoButton.addEventListener('click', () => {
                menu.style.display = 'block';
            });

            // Fechar menu ao clicar fora dele
            window.addEventListener('click', (event) => {
                if (!menu.contains(event.target) && event.target !== editPhotoButton) {
                    menu.style.display = 'none';
                }
            });

            // Escolher foto na galeria
            chooseLibrary.addEventListener('click', () => {
                fileInput.click();
            });

            // Alterar a foto de perfil ao selecionar arquivo
            fileInput.addEventListener('change', (event) => {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        profileePic.style.backgroundImage = \`url('\${e.target.result}')\`;
                        menu.style.display = 'none';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Remover foto atual
            removePhoto.addEventListener('click', () => {
                profileePic.style.backgroundImage = \`url('./uploads/default.png')\`;
                menu.style.display = 'none';
            });

            // Restaurar foto original
            resetPhoto.addEventListener('click', () => {
                profileePic.style.backgroundImage = \`url('${user.photo}')\`;
                menu.style.display = 'none';
            });

 // Salvar alterações
saveButton.addEventListener('click', () => {
    const formData = new FormData();
    formData.append('name', document.getElementById('name').value);
    formData.append('username', document.getElementById('username').value);
    formData.append('legend', document.getElementById('legend').value);
    formData.append('category', document.getElementById('category').value);

    const photoFile = fileInput.files[0];
    const currentPhotoUrl = profileePic.style.backgroundImage.slice(5, -2).replace(/^["'](.+(?=["']$))["']$/, '$1');

    if (photoFile) {
        formData.append('photo', photoFile);
    } else {
        // Verificar se a foto atual é a foto padrão
        if (currentPhotoUrl.includes('default.png') || currentPhotoUrl === './uploads/default.png') {
            formData.append('photo', './uploads/default.png');
        } else {
            formData.append('photo', currentPhotoUrl);
        }
    }

    fetch('/edit-profilee', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Perfil atualizado com sucesso!');
        } else {
            alert('Erro ao atualizar perfil: ' + data.message);
        }
    })
    .catch((error) => {
        console.error('Erro:', error);
        alert('Erro ao atualizar perfil. Tente novamente.');
    });
});
        </script>

    </body>
    </html>
    `)
    })

app.post('/create-account', async (req, res) => {
  const { name, username, email, phone, password } = req.body;

  // Verifica se todos os campos estão preenchidos
  if (!name || !username || !email || !phone || !password) {
    return res.status(400).send('Todos os campos são obrigatórios!');
  }

  // Valida o username: deve conter apenas letras, números, _ e .
  const usernameRegex = /^[a-zA-Z0-9_.]+$/;
  if (!usernameRegex.test(username)) {
    return res.status(400).send('⚠️ Nome de usuário inválido!\nℹ️ Use apenas letras, números, _ e .');
  }

  // Converte o username para minúsculas
  const formattedUsername = username.toLowerCase();

  // Verifica se o username já está em uso
  const users = loadUsers();
  const usernameExists = users.some(user => user.username === formattedUsername);
  if (usernameExists) {
    return res.status(400).send('👤 Esse nome de usuário já está em uso.');
  }

  // Verifica se o email já está em uso
  const emailExists = users.some(user => user.email === email);
  if (emailExists) {
    return res.status(400).send('✉️ Esse email já está em uso.');
  }

  // Verifica se o telefone já está em uso
const phoneExists = users.some(user => user.phone === phone);
  if (phoneExists) {
    return res.status(400).send('📞 Esse número de telefone já está em uso.');
  }

  // Verifica se a senha tem pelo menos 8 dígitos
  if (password.length < 8) {
    return res.status(400).send('🔐 A senha deve ter no mínimo 8 dígitos.');
  }

  // Gera o hash da senha
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  // Cria o novo usuário
  const newUser = {
    id: Date.now(),
    name,
    username: formattedUsername, // Salva o username em minúsculas
    email,
    phone,
    password: hashedPassword, // Salva a senha criptografada
    photo: "/uploads/default.png",
    category: "",
    legend: "",
    bio: "",
    suspended: false,
    country: 'Brasil',
    posts: [],
    chats: [],
    followersB: 0,
    followers: [],
    followingB: 0,
    following: [],
    verifications: {
      azul: false,
      verde: false,
      vermelho: false,
      amarelo: false,
      roxo: false,
      colorido: false,
    },
  };

  // Salva o novo usuário
  users.push(newUser);
  saveUser(users);

  res.status(201).send('✅ Conta criada com sucesso!');
});

app.get('/chats', isAuthenticated, (req, res) => {
  const chats = loadChats();
  const userIde = req.session.userId;
  const users = loadUsers();
  const user2 = users.find(u => u.id == userIde);
  const currentUser = getUserById(req.session.userId);

  if (!currentUser) {
    return res.status(404).send('Usuário não encontrado.');
  }

  let userChats = chats.filter(chat =>
    chat.participants.includes(user2.id)
  ).map(chat => {
    const otherUserId = chat.participants.find(id => id !== user2.id);
    const otherUser = getUserById(otherUserId);
    const lastMessage = chat.messages[chat.messages.length - 1];
    const isUnread = lastMessage.isUnread && lastMessage.senderId !== user2.id;

let verificationBadge = getVerificationBadge(otherUser.verifications);

    return {
 //     id: chat.id,
      otherUser: {
        id: otherUser.id,
        name: otherUser.name,
        photo: otherUser.photo,
        verified: otherUser.verifications,
        verificationBadge: verificationBadge
      },
      lastMessage: lastMessage.content,
      timestamp: lastMessage.timestamp,
      isUnread: isUnread
    };
  });

  // Ordena os chats pelo timestamp da última mensagem
  userChats = userChats.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  const html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Mensagens</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            border-bottom: 1px solid #333;
        }
        .header h1 {
            font-size: 18px;
        }
        .header .icons i {
            margin-left: 10px;
            margin-right: 10px;
            font-size: 20px;
            color: #fff;
        }
        .search-bar {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #333;
            border-radius: 20px;
            margin: 10px;
        }
        .search-bar input {
            background: none;
            border: none;
            color: #fff;
            margin-left: 10px;
            width: 100%;
        }
        .search-bar i {
            font-size: 20px;
            color: #fff;
        }
        .messages-text {
            padding: 10px;
            font-size: 36px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 10px;
            margin-top: -20px;
            border-bottom: 1px solid #333;
        }
        .message {
            border-bottom: 1px solid #333;
            display: flex;
            align-items: center;
            margin-top: 0px;
            margin-bottom: -1px;
            padding: 10px;
        }
        .message img {
            border-radius: 50%;
            width: 50px;
            height: 50px;
            margin-right: 10px;
        }
        .message-info {
            display: flex;
            flex-direction: column;
        } 
        .message-info .user-name {
            font-size: 18px;
            display: flex;
            align-items: center;
        }
        .message-info .status {
            font-size: 14px;
            color: #888;
        }
        .unread-dot {
            width: 10px;
            height: 10px;
            background-color: blue;
            border-radius: 50%;
            display: inline-block;
            margin-left: 5px;
        }
        .verified {
            font-size: 13px;
            color: #00b0ff;
            margin-left: 4px;
        }
        .arrow-icon {
            font-size: 18px;
            margin-left: 10px;
            color: #fff;
        }
        .name {
            font-size: 18px;
            margin-right: 7px;
        }
        .header .back-icon {
            font-size: 20px;
            color: #fff;
            margin-right: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="user-info">
        <a href="/" style="text-decoration: none; color: #fff;">
        <i class="fas fa-arrow-left back-icon"></i>
        </a>
            <span class="name">${user2.username}</span>
        </div>
        <div class="icons">
            <i class="fas fa-heart"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-user"></i>
        </div>
    </div>

    <div class="search-bar">
        <i class="fas fa-search"></i>
        <input type="text" placeholder="Pesquise por usuários...">
    </div>

    <div class="messages-text">
        <span>Mensagens</span>
    </div>

<div class="messages">
  ${userChats.map(chat => `
    <a href="/chat/${chat.otherUser.id}" onclick="openChat(${chat.otherUser.id})" style="text-decoration: none; color: #fff;">
      <div class="message">
        <img src="${chat.otherUser.photo}" alt="${chat.otherUser.name}">
        <div class="message-info">
          <span class="user-name">
            ${chat.otherUser.name} 
            ${chat.otherUser.verificationBadge}        
            ${chat.isUnread ? '<span class="unread-dot"></span>' : ''}
          </span>
          <span class="status">
            ${chat.lastMessage} 
            • ${new Date(chat.timestamp).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
          </span>
        </div>
      </div>
    </a>
  `).join('')}
</div>
<script>
function openChat(recipientId) {
  fetch("/chat"+recipientId)
    .then(response => response.text()) // Altere para response.text() se o backend retornar HTML
    .then(html => {
      document.querySelector('.chat-window').innerHTML = html;

      // Atualiza a lista de chats para remover a bolinha azul
      updateChatList();
    });
}

function updateChatList() {
  fetch('/chats')
    .then(response => response.text())
    .then(html => {
      document.querySelector('.messages').innerHTML = html;
    });
}
</script>
</body>
</html>
  `;

  res.send(html);
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/check-auth', (req, res) => {
  if (req.session.userId) {
    res.status(200).send('Autenticado');
  } else {
    res.status(401).send('Não autenticado');
  }
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const users = loadUsers();
  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(400).send('❌ E-mail ou senha incorretos.');
  }

  // Compara a senha fornecida com o hash armazenado
  const isPasswordValid = await bcrypt.compare(password, user.password);

  if (!isPasswordValid) {
    return res.status(400).send('❌ E-mail ou senha incorretos.');
  }

  req.session.userId = user.id;
  res.redirect('/');
});

app.get('/chat', isAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'chat.html'));
});



// Rota principal para servir a página HTML
app.get("/search", isAuthenticated, (req, res) => {
const users = loadUsers();
  res.send(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Pesquisar Usuários</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #000;
          color: #fff;
        }

        .top-bar {
          display: flex;
          align-items: center;
          padding: 10px;
          background-color: #121212;
          border-bottom: 1px solid #333;
        }

        .search-bar {
          flex: 1;
          display: flex;
          align-items: center;
          background-color: #333;
          border-radius: 20px;
          padding: 5px 10px;
        }

        .search-bar input {
          flex: 1;
          background: none;
          border: none;
          color: #fff;
          padding: 5px;
          outline: none;
        }

        .results {
          padding: 10px;
        }

        .user {
          display: flex;
          align-items: center;
          margin: 10px 0;
          padding: 10px;
          background-color: #222;
          border-radius: 10px;
        }

        .user img {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          margin-right: 10px;
        }

        .user-info {
          display: flex;
          flex-direction: column;
        }
        
        .verified {
            font-size: 14px;
            color: #00b0ff;
            margin-left: 0px;
        }
        
        .user-info strong {
          font-size: 16px;
          margin-bottom: 2px;
        }

        .user-info span {
          font-size: 14px;
          color: #ccc;
        }
        a {
  color: inherit; /* Para garantir que a cor do link seja a mesma do texto */
  text-decoration: none; /* Remove o sublinhado */
}

a:hover {
  color: #fff; /* Cor de hover para o link, se necessário */
}
      </style>
    </head>
    <body>
      <div class="top-bar">
        <div class="search-bar">
          <i class="fas fa-search" style="color: #fff; margin-right: 5px;"></i>
          <input
            type="text"
            id="searchInput"
            placeholder="Pesquise por usuários..."
            oninput="searchUsers()">
        </div>
      </div>

      <div class="results" id="results"></div>

      <script>
        async function searchUsers() {
          const query = document.getElementById("searchInput").value;

          // Fazer a requisição ao servidor
          const response = await fetch(\`/searchh?q=\${encodeURIComponent(query)}\`);
          const users = await response.json();

          // Atualizar a lista de usuários
          const resultsDiv = document.getElementById("results");
          resultsDiv.innerHTML = ""; // Limpar resultados anteriores

          users.forEach(user => {
  const userDiv = document.createElement("div");
  userDiv.classList.add("user");
  
  // Envolvendo o userDiv com um link
const userLink = document.createElement("a");
userLink.href = "/profile-user/" + encodeURIComponent(user.username);
userLink.style.display = "block";  // Para que a tag <a> ocupe todo o espaço
userLink.style.textDecoration = "none";  // Remover sublinhado do link
           
           let verificationBadge = '';
    if (user.verifications.azul) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="blue" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (user.verifications.verde) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="green" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (user.verifications.vermelho) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="red" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (user.verifications.amarelo) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="yellow" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (user.verifications.roxo) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="purple" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path></svg>';
    } else if (user.verifications.colorido) {
      verificationBadge = '<svg class="verified" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" class="iconify iconify--ic" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 26 26" data-icon="ic:baseline-verified" onclick="showPopup(event)"><path fill="url(#grad1)" d="m23 12l-2.44-2.79l.34-3.69l-3.61-.82l-1.89-3.2L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5l.34 3.7L1 12l2.44 2.79l-.34 3.7l3.61.82L8.6 22.5l3.4-1.47l3.4 1.46l1.89-3.19l3.61-.82l-.34-3.69L23 12zm-12.91 4.72l-3.8-3.81l1.48-1.48l2.32 2.33l5.85-5.87l1.48 1.48l-7.33 7.35z"></path><defs><linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" style="stop-color:red;stop-opacity:1" /><stop offset="20%" style="stop-color:orange;stop-opacity:1" /><stop offset="40%" style="stop-color:yellow;stop-opacity:1" /><stop offset="60%" style="stop-color:green;stop-opacity:1" /><stop offset="80%" style="stop-color:blue;stop-opacity:1" /><stop offset="100%" style="stop-color:purple;stop-opacity:1" /></linearGradient></defs></svg>';
    }
    
            userDiv.innerHTML = \`
              <img src="\${user.photo}" alt="\${user.name}">
              <div class="user-info">
                <strong>\${user.name} \${verificationBadge}</strong>
                <span>\${user.username}</span>
              </div>
            \`;

            userLink.appendChild(userDiv);
  resultsDiv.appendChild(userLink)
          });
        }
      </script>
    </body>
    </html>
  `);
});

// Rota para pesquisa de usuários
app.get("/searchh", (req, res) => {
const users = loadUsers();
  const query = req.query.q?.toLowerCase() || "";

  // Filtrar usuários apenas se houver texto digitado
  const filteredUsers = query
    ? users.filter(user =>
        user.name.toLowerCase().includes(query) || user.username.toLowerCase().includes(query)
      )
    : [];

  res.json(filteredUsers); // Retornar os usuários como JSON
});


app.post("/save-photo", (req, res) => {
  const { image, id } = req.body;

  const base64Data = image.replace(/^data:image\/png;base64,/, "");
  const buffer = Buffer.from(base64Data, "base64");

  const photoPath = path.join(__dirname, "imagens", `${id}.png`);

  fs.writeFile(photoPath, buffer, (err) => {
    if (err) {
      console.error("Erro ao salvar a foto:", err);
      return res.status(500).send("Erro ao salvar a foto.");
    }

    res.status(200).send("Foto salva com sucesso!");
  });
});



app.get('/admin/view-users', isAuthenticated2, (req, res) => {
const users = loadUsers();
    const userOptions = users
        .map(user => `<option value="${user.id}">${user.name} (${user.username})</option>`)
        .join('');

    const html = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Painel Administrativo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1c1c1e;
            color: #fff;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #2c2c2e;
            border-radius: 10px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .profilee-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto 10px;
            background-size: cover;
            background-position: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        select, button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #444;
            color: #fff;
            margin-top: 10px;
        }
        #user-details {
            display: none;
            margin-top: 20px;
            padding: 20px;
            background-color: #2c2c2e;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <h1>Visualizar Usuário</h1>
    <div class="container">
        <div class="form-group">
            <label for="user-select">Selecione um usuário:</label>
            <select id="user-select">
                <option value="" disabled selected>Escolha um usuário</option>
                ${userOptions}
            </select>
        </div>
        <div id="user-details">
            <div class="header">
                <div class="profilee-pic" id="profilee-pic" style="background-image: url('./uploads/default.png');"></div>
            </div>
            <div>
                <p><strong>Nome:</strong> <span id="user-name"></span></p>
                <p><strong>Nome de Usuário:</strong> <span id="user-username"></span></p>
                <p><strong>Verificado:</strong> <span id="user-verifications"></span></p>
                <p><strong>Seguidores reais:</strong> <span id="user-real-followers"></span></p>
                <p><strong>Seguidores burlados:</strong> <span id="user-fake-followers"></span></p>
                <p><strong>Seguindo:</strong> <span id="following"></span></p>
                <p><strong>Posts:</strong> <span id="posts"></span></p>
                <p><strong>Email:</strong> <span id="user-email"></span></p>
                <p><strong>ID:</strong> <span id="user-id"></span></p>
                
                <!-- Botão para ver posts, com link para a página de posts -->
                <a id="view-posts-button" href="" class="button">Ver Posts</a>
                
                <!-- Botão para editar usuário, com link para a página de edição -->
                <a id="edit-user-button" href="" class="button">Configurar Usuário</a>
            </div>
        </div>
    </div>

    <script>
        const users = ${JSON.stringify(users)};
        const userSelect = document.getElementById('user-select');
        const userDetails = document.getElementById('user-details');
        const profilePic = document.getElementById('profilee-pic');
        const userName = document.getElementById('user-name');
        const userUsername = document.getElementById('user-username');
        const userVerifications = document.getElementById('user-verifications');
        const userRealFollowers = document.getElementById('user-real-followers');
        const userFakeFollowers = document.getElementById('user-fake-followers');
        const userEmail = document.getElementById('user-email');
        const userId = document.getElementById('user-id');
        const userPosts = document.getElementById('posts');
        const userFollowing = document.getElementById('following');
        const viewPostsButton = document.getElementById('view-posts-button');
        const editUserButton = document.getElementById('edit-user-button');

        userSelect.addEventListener('change', (e) => {
            const selectedUserId = parseInt(e.target.value, 10);
            const user = users.find(u => u.id === selectedUserId);

            if (user) {
                userDetails.style.display = 'block';
                profilePic.style.backgroundImage = 'url(' + user.photo + ')';
                userName.textContent = user.name;
                userUsername.textContent = user.username;
                userEmail.textContent = user.email;
                userId.textContent = user.id;
                userRealFollowers.textContent = user.followers.length;
                userFollowing.textContent = user.following.length;
                userFakeFollowers.textContent = user.followersB;
                userPosts.textContent = user.posts.length;

                // Exibir a verificação
                const verifiedColor = Object.keys(user.verifications).find(color => user.verifications[color]);
                userVerifications.textContent = verifiedColor ? 'Sim (' + verifiedColor + ')' : 'Não';

                // Atualiza os links dos botões
                viewPostsButton.href = "/view-posts/"+user.id;
                editUserButton.href = "/edit-user/"+user.id;
            }
        });
    </script>
</body>
</html>
    `;
    res.send(html);
});


// Página para visualizar os posts de um usuário
app.get('/view-posts/:userId', isAuthenticated2, (req, res) => {
    const userId = parseInt(req.params.userId, 10);
    const users = loadUsers();
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send('Usuário não encontrado.');
    }

    const postsHtml = user.posts
    .map(post => `
        <div style="border: 1px solid #444; padding: 10px; margin-bottom: 10px;">
            <img src="${post.Post}" alt="Post" style="max-width: 100%; border-radius: 5px;">
            <p><strong>Likes Reais:</strong> ${post.Likes.length}</p>
            <p><strong>Likes Burlados:</strong></p>
            <input type="number" id="likesB-${post.postId}" value="${post.LikesB}" style="width: 100%; padding: 5px; border-radius: 5px; margin-bottom: 10px;">
            <p><strong>Descrição:</strong></p>
            <textarea id="description-${post.postId}" style="width: 100%; padding: 5px; border-radius: 5px; margin-bottom: 10px;">${post.Description}</textarea>
            <p><strong>Data:</strong> ${post.DateTime}</p>
            <p><strong>Comentários:</strong> ${post.Coments.length}</p>
            <button onclick="saveLikesB(${userId}, ${post.postId})" style="background-color: green; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer;">Salvar Likes</button>
            <button onclick="saveDescription(${userId}, ${post.postId})" style="background-color: blue; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer;">Salvar Descrição</button>
            <button onclick="deletePost(${userId}, ${post.postId})" style="background-color: red; color: white; border: none; padding: 5px 10px; border-radius: 5px; cursor: pointer;">Apagar Post</button>
        </div>
    `)
    .join('');

const html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">
        <title>Posts de ${user.name}</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #1c1c1e;
                color: #fff;
                padding: 20px;
            }
            .container {
                max-width: 600px;
                margin: 0 auto;
            }
            textarea, input { width: 90%; padding: 10px; border: none; border-radius: 5px; background-color: #444; color: #fff; margin-top: 10px; }
            button {
                padding: 5px 10px;
                border-radius: 5px;
                cursor: pointer;
                border: none;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Posts de ${user.name}</h1>
            ${postsHtml}
        </div>
        <script>
            function saveLikesB(userId, postId) {
                const likesB = document.getElementById('likesB-' + postId).value;
                fetch('/update-likesB', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ userId, postId, likesB }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Likes Burlados atualizados com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro ao salvar Likes Burlados: ' + data.message);
                    }
                })
                .catch(err => {
                    alert('Erro na solicitação: ' + err.message);
                });
            }

            function saveDescription(userId, postId) {
                const description = document.getElementById('description-' + postId).value;
                fetch('/update-description', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ userId, postId, description }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Descrição atualizada com sucesso!');
                        location.reload();
                    } else {
                        alert('Erro ao salvar descrição: ' + data.message);
                    }
                })
                .catch(err => {
                    alert('Erro na solicitação: ' + err.message);
                });
            }

            function deletePost(userId, postId) {
                if (confirm('Tem certeza de que deseja apagar este post?')) {
                    fetch('/delete-post', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ userId, postId }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Post apagado com sucesso!');
                            location.reload();
                        } else {
                            alert('Erro ao apagar o post: ' + data.message);
                        }
                    })
                    .catch(err => {
                        alert('Erro na solicitação: ' + err.message);
                    });
                }
            }
        </script>
    </body>
    </html>
`;
    res.send(html);
});

// Página para editar as informações do usuário


app.post('/update-description', (req, res) => {
    const { userId, postId, description } = req.body;
    const users = loadUsers();

    const user = users.find(u => u.id === userId);
    if (!user) {
        return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    const post = user.posts.find(p => p.postId === postId);
    if (!post) {
        return res.status(404).json({ success: false, message: 'Post não encontrado.' });
    }

    post.Description = description; // Atualiza a descrição
    saveUser(users); // Função para salvar os dados no arquivo JSON

    res.json({ success: true });
});

app.post('/update-likesB', (req, res) => {
    const { userId, postId, likesB } = req.body;
    const users = loadUsers();

    const user = users.find(u => u.id === userId);
    if (!user) {
        return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    const post = user.posts.find(p => p.postId === postId);
    if (!post) {
        return res.status(404).json({ success: false, message: 'Post não encontrado.' });
    }

    post.LikesB = likesB; // Atualiza o campo LikesB
    saveUser(users); // Função para salvar os dados no arquivo JSON

    res.json({ success: true });
});

app.get('/edit-user/:userId', isAuthenticated2, (req, res) => {
  const users = loadUsers();
      const userId = parseInt(req.params.userId, 10);
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send('Usuário não encontrado');
    }

    const verificationOptions = Object.keys(user.verifications)
        .map(key => `<option value="${key}" ${user.verifications[key] ? 'selected' : ''}>${key.charAt(0).toUpperCase() + key.slice(1)}</option>`)
        .join('');

    const html = `
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="/uploads/mexus.png" type="image/png">
<title>Editar Usuário</title>
        <style>
            body { font-family: Arial, sans-serif; background-color: #1c1c1e; color: #fff; margin: 0; padding: 20px; }
            .container { max-width: 400px; margin: 0 auto; padding: 20px; background-color: #2c2c2e; border-radius: 10px; }
            .form-group { margin-bottom: 15px; }
            label { display: block; margin-bottom: 5px; }
            input, select, textarea, button { width: 100%; padding: 10px; border: none; border-radius: 5px; background-color: #444; color: #fff; margin-top: 10px; }
        </style>
    </head>
    <body>
        <h1>Editar Usuário: ${user.name}</h1>
        <div class="container">
            <form action="/save-user/${user.id}" method="POST">
                <div class="form-group">
                    <label for="user-name">Nome:</label>
                    <input type="text" id="user-name" name="name" value="${user.name}" required />
                </div>
                <div class="form-group">
                    <label for="user-username">Nome de Usuário:</label>
                    <input type="text" id="user-username" name="username" value="${user.username}" required />
                </div>
                <div class="form-group">
                    <label for="user-email">Email:</label>
                    <input type="email" id="user-email" name="email" value="${user.email}" required />
                </div>
                <div class="form-group">
                    <label for="user-phone">Telefone:</label>
                    <input type="text" id="user-phone" name="phone" value="${user.phone}" />
                </div>
                <div class="form-group">
                    <label for="user-category">Categoria:</label>
                    <input type="text" id="user-category" name="category" value="${user.category}" />
                </div>
                <div class="form-group">
                    <label for="user-legend">Bio:</label>
                    <textarea id="user-legend" name="legend">${user.legend}</textarea>
                </div>
                <div class="form-group">
                    <label for="user-followersB">Seguidores Burlados:</label>
                    <input type="number" id="user-followersB" name="followersB" value="${user.followersB}" />
                </div>
                <div class="form-group">
                    <label for="user-suspended">Suspensão:</label>
                    <select id="user-suspended" name="suspended">
                        <option value="false" ${!user.suspended ? 'selected' : ''}>Não</option>
                        <option value="true" ${user.suspended ? 'selected' : ''}>Sim</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="user-verification">Selecione o Selo:</label>
                    <select id="user-verification" name="verification">
                        <option value="" ${Object.values(user.verifications).every(v => !v) ? 'selected' : ''}>Nenhum</option>
                        ${verificationOptions}
                    </select>
                </div>
                <button type="submit">Salvar Alterações</button>
            </form>
            <a href="/admin/view-users">Voltar ao Painel Administrativo</a>
        </div>
    </body>
    </html>
    `;
    res.send(html);
});


app.post('/save-user/:userId', (req, res) => {
const users = loadUsers();
    const userId = parseInt(req.params.userId, 10);
    const user = users.find(u => u.id === userId);

    if (!user) {
        return res.status(404).send('Usuário não encontrado');
    }

    // Atualiza os dados do usuário
    user.name = req.body.name;
    user.username = req.body.username;
    user.email = req.body.email;
    user.phone = req.body.phone || user.phone;
    user.category = req.body.category || user.category;
    user.legend = req.body.legend || user.legend;
    user.followersB = parseInt(req.body.followersB, 10) || user.followersB;
    user.suspended = req.body.suspended === 'true';

    // Atualiza as verificações
    const verificationKey = req.body.verification;
    Object.keys(user.verifications).forEach(key => {
        user.verifications[key] = key === verificationKey;
    });

    saveUser(users); // Função para salvar no arquivo JSON

    //res.redirect('/admin'); // Redireciona para o painel administrativo
});

// Rota para excluir um post
app.post('/delete-post', (req, res) => {
    console.log('Dados recebidos:', req.body);

    const { userId, postId } = req.body;

    if (!userId || !postId) {
        console.error('Dados inválidos:', req.body);
        return res.status(400).json({ success: false, message: 'Dados inválidos.' });
    }

    const users = loadUsers();
    const user = users.find(u => u.id === userId);

    if (!user) {
        console.error('Usuário não encontrado:', userId);
        return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    const postIndex = user.posts.findIndex(post => post.postId === postId);

    if (postIndex === -1) {
        console.error('Post não encontrado:', postId);
        return res.status(404).json({ success: false, message: 'Post não encontrado.' });
    }

    user.posts.splice(postIndex, 1);
    saveUser(users);

    console.log('Post removido com sucesso:', postId);
    res.json({ success: true });
});
// Função para salvar os dados dos usuários (simulando persistên


app.post('/login-adm', (req, res) => {
  const { email, pass } = req.body;

  const adms = loadAdms();
  const adm = adms.find(u => u.email === email);

  if (!adm) {
    return res.status(400).send('❌ E-mail ou senha incorretos.');
  }

  // Compara a senha fornecida diretamente
  if (pass !== adm.pass) {
    return res.status(400).send('❌ E-mail ou senha incorretos.');
  }

  req.session.userId = adm.id;
  res.redirect('/admin/view-users');
});


app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'loginAdm.html'));
});

app.get('/c', (req, res) => {
  res.sendFile(path.join(__dirname, 'coments.html'));
});

http.listen(PORT, () => {
  console.log(`Servidor rodando em: ${domain}`);
});
